﻿
namespace Robotic_Arm_Drawing_Demo
{
    partial class frm_main
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_connect = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_clear = new System.Windows.Forms.Button();
            this.btn_set_colour = new System.Windows.Forms.Button();
            this.txt_msg = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_Board_Dimension = new System.Windows.Forms.TextBox();
            this.lbl_local_board_dimension = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_mousePosY = new System.Windows.Forms.TextBox();
            this.txt_mousePosX = new System.Windows.Forms.TextBox();
            this.lbl_robot_board_dimension = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_robot_pen = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_robot_board_PosY = new System.Windows.Forms.TextBox();
            this.txt_robot_board_PosX = new System.Windows.Forms.TextBox();
            this.txt_rbt_pos_string = new System.Windows.Forms.TextBox();
            this.btn_pos_send = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btn_get_pos = new System.Windows.Forms.Button();
            this.txt_send_string = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(21, 22);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(624, 271);
            this.panel1.TabIndex = 0;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            this.panel1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
            // 
            // btn_connect
            // 
            this.btn_connect.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btn_connect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_connect.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_connect.ForeColor = System.Drawing.Color.White;
            this.btn_connect.Location = new System.Drawing.Point(6, 22);
            this.btn_connect.Name = "btn_connect";
            this.btn_connect.Size = new System.Drawing.Size(89, 47);
            this.btn_connect.TabIndex = 1;
            this.btn_connect.Text = "Connect";
            this.btn_connect.UseVisualStyleBackColor = false;
            this.btn_connect.Click += new System.EventHandler(this.btn_connect_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.groupBox1.Controls.Add(this.btn_clear);
            this.groupBox1.Controls.Add(this.btn_set_colour);
            this.groupBox1.Controls.Add(this.btn_connect);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(694, 77);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(105, 310);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "CONTROL";
            // 
            // btn_clear
            // 
            this.btn_clear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btn_clear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_clear.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_clear.ForeColor = System.Drawing.Color.White;
            this.btn_clear.Location = new System.Drawing.Point(6, 259);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(89, 34);
            this.btn_clear.TabIndex = 1;
            this.btn_clear.Text = "Clear";
            this.btn_clear.UseVisualStyleBackColor = false;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click);
            // 
            // btn_set_colour
            // 
            this.btn_set_colour.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btn_set_colour.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_set_colour.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_set_colour.ForeColor = System.Drawing.Color.White;
            this.btn_set_colour.Location = new System.Drawing.Point(6, 75);
            this.btn_set_colour.Name = "btn_set_colour";
            this.btn_set_colour.Size = new System.Drawing.Size(89, 57);
            this.btn_set_colour.TabIndex = 1;
            this.btn_set_colour.Text = "Set Colour";
            this.btn_set_colour.UseVisualStyleBackColor = false;
            this.btn_set_colour.Click += new System.EventHandler(this.btn_set_colour_Click);
            // 
            // txt_msg
            // 
            this.txt_msg.Location = new System.Drawing.Point(22, 589);
            this.txt_msg.Name = "txt_msg";
            this.txt_msg.Size = new System.Drawing.Size(777, 23);
            this.txt_msg.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Navy;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(122, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(425, 37);
            this.label1.TabIndex = 4;
            this.label1.Text = "Robotic ARM Drawing Demo";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Robotic_Arm_Drawing_Demo.Properties.Resources.srivas_university;
            this.pictureBox1.Location = new System.Drawing.Point(599, 18);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(200, 44);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.txt_Board_Dimension);
            this.groupBox2.Controls.Add(this.lbl_local_board_dimension);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txt_mousePosY);
            this.groupBox2.Controls.Add(this.txt_mousePosX);
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(22, 393);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(320, 97);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Local Board Details";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(171, 27);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 21);
            this.label3.TabIndex = 1;
            this.label3.Text = "Mouse Y";
            // 
            // txt_Board_Dimension
            // 
            this.txt_Board_Dimension.Location = new System.Drawing.Point(156, 62);
            this.txt_Board_Dimension.Name = "txt_Board_Dimension";
            this.txt_Board_Dimension.Size = new System.Drawing.Size(120, 23);
            this.txt_Board_Dimension.TabIndex = 0;
            // 
            // lbl_local_board_dimension
            // 
            this.lbl_local_board_dimension.AutoSize = true;
            this.lbl_local_board_dimension.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_local_board_dimension.Location = new System.Drawing.Point(9, 64);
            this.lbl_local_board_dimension.Name = "lbl_local_board_dimension";
            this.lbl_local_board_dimension.Size = new System.Drawing.Size(130, 21);
            this.lbl_local_board_dimension.TabIndex = 1;
            this.lbl_local_board_dimension.Text = "Board Dimension";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(9, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 21);
            this.label2.TabIndex = 1;
            this.label2.Text = "Mouse X";
            // 
            // txt_mousePosY
            // 
            this.txt_mousePosY.Location = new System.Drawing.Point(260, 28);
            this.txt_mousePosY.Name = "txt_mousePosY";
            this.txt_mousePosY.Size = new System.Drawing.Size(56, 23);
            this.txt_mousePosY.TabIndex = 0;
            // 
            // txt_mousePosX
            // 
            this.txt_mousePosX.Location = new System.Drawing.Point(91, 28);
            this.txt_mousePosX.Name = "txt_mousePosX";
            this.txt_mousePosX.Size = new System.Drawing.Size(56, 23);
            this.txt_mousePosX.TabIndex = 0;
            // 
            // lbl_robot_board_dimension
            // 
            this.lbl_robot_board_dimension.AutoSize = true;
            this.lbl_robot_board_dimension.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_robot_board_dimension.Location = new System.Drawing.Point(6, 64);
            this.lbl_robot_board_dimension.Name = "lbl_robot_board_dimension";
            this.lbl_robot_board_dimension.Size = new System.Drawing.Size(85, 21);
            this.lbl_robot_board_dimension.TabIndex = 1;
            this.lbl_robot_board_dimension.Text = "Dimension";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(6, 22);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(81, 21);
            this.label6.TabIndex = 1;
            this.label6.Text = "Robot Pen";
            // 
            // txt_robot_pen
            // 
            this.txt_robot_pen.Location = new System.Drawing.Point(93, 24);
            this.txt_robot_pen.Name = "txt_robot_pen";
            this.txt_robot_pen.Size = new System.Drawing.Size(134, 23);
            this.txt_robot_pen.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel2.Controls.Add(this.panel1);
            this.panel2.Location = new System.Drawing.Point(22, 77);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(667, 310);
            this.panel2.TabIndex = 7;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.lbl_robot_board_dimension);
            this.groupBox3.Controls.Add(this.txt_robot_pen);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.txt_robot_board_PosY);
            this.groupBox3.Controls.Add(this.txt_robot_board_PosX);
            this.groupBox3.ForeColor = System.Drawing.Color.Yellow;
            this.groupBox3.Location = new System.Drawing.Point(347, 393);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(452, 97);
            this.groupBox3.TabIndex = 8;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Robot Board Details";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(245, 60);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(70, 21);
            this.label5.TabIndex = 1;
            this.label5.Text = "Mouse Y";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(245, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 21);
            this.label4.TabIndex = 1;
            this.label4.Text = "Mouse X";
            // 
            // txt_robot_board_PosY
            // 
            this.txt_robot_board_PosY.Location = new System.Drawing.Point(318, 60);
            this.txt_robot_board_PosY.Name = "txt_robot_board_PosY";
            this.txt_robot_board_PosY.Size = new System.Drawing.Size(124, 23);
            this.txt_robot_board_PosY.TabIndex = 0;
            // 
            // txt_robot_board_PosX
            // 
            this.txt_robot_board_PosX.Location = new System.Drawing.Point(319, 28);
            this.txt_robot_board_PosX.Name = "txt_robot_board_PosX";
            this.txt_robot_board_PosX.Size = new System.Drawing.Size(123, 23);
            this.txt_robot_board_PosX.TabIndex = 0;
            // 
            // txt_rbt_pos_string
            // 
            this.txt_rbt_pos_string.Location = new System.Drawing.Point(9, 58);
            this.txt_rbt_pos_string.Name = "txt_rbt_pos_string";
            this.txt_rbt_pos_string.Size = new System.Drawing.Size(214, 23);
            this.txt_rbt_pos_string.TabIndex = 0;
            this.txt_rbt_pos_string.Text = "310.3 , 1116.8 ,0 , -180 , 0.0 , 0.0";
            // 
            // btn_pos_send
            // 
            this.btn_pos_send.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_pos_send.Location = new System.Drawing.Point(671, 22);
            this.btn_pos_send.Name = "btn_pos_send";
            this.btn_pos_send.Size = new System.Drawing.Size(100, 59);
            this.btn_pos_send.TabIndex = 9;
            this.btn_pos_send.Text = "MOVE";
            this.btn_pos_send.UseVisualStyleBackColor = true;
            this.btn_pos_send.Click += new System.EventHandler(this.btn_pos_send_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.btn_get_pos);
            this.groupBox4.Controls.Add(this.txt_send_string);
            this.groupBox4.Controls.Add(this.txt_rbt_pos_string);
            this.groupBox4.Controls.Add(this.btn_pos_send);
            this.groupBox4.ForeColor = System.Drawing.Color.White;
            this.groupBox4.Location = new System.Drawing.Point(22, 491);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(777, 92);
            this.groupBox4.TabIndex = 10;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Robot Parameter";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(9, 37);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(62, 15);
            this.label8.TabIndex = 11;
            this.label8.Text = "Get  String";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(451, 40);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 15);
            this.label7.TabIndex = 11;
            this.label7.Text = "Send String";
            // 
            // btn_get_pos
            // 
            this.btn_get_pos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_get_pos.Location = new System.Drawing.Point(241, 22);
            this.btn_get_pos.Name = "btn_get_pos";
            this.btn_get_pos.Size = new System.Drawing.Size(100, 59);
            this.btn_get_pos.TabIndex = 10;
            this.btn_get_pos.Text = "Get Pos";
            this.btn_get_pos.UseVisualStyleBackColor = true;
            this.btn_get_pos.Click += new System.EventHandler(this.btn_get_pos_Click);
            // 
            // txt_send_string
            // 
            this.txt_send_string.Location = new System.Drawing.Point(408, 58);
            this.txt_send_string.Name = "txt_send_string";
            this.txt_send_string.Size = new System.Drawing.Size(257, 23);
            this.txt_send_string.TabIndex = 0;
            this.txt_send_string.Text = "375.0 , 1032.0 , 0.0 , 180.0 , 0.0 , 0.0";
            // 
            // frm_main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(811, 624);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_msg);
            this.Controls.Add(this.groupBox1);
            this.Name = "frm_main";
            this.Text = "Robotic ARM Drawing Demo V1.0";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_connect;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.Button btn_set_colour;
        private System.Windows.Forms.TextBox txt_msg;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_mousePosY;
        private System.Windows.Forms.TextBox txt_mousePosX;
        private System.Windows.Forms.Label lbl_local_board_dimension;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_robot_pen;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbl_robot_board_dimension;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txt_Board_Dimension;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_robot_board_PosY;
        private System.Windows.Forms.TextBox txt_robot_board_PosX;
        private System.Windows.Forms.TextBox txt_rbt_pos_string;
        private System.Windows.Forms.Button btn_pos_send;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btn_get_pos;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_send_string;
    }
}

