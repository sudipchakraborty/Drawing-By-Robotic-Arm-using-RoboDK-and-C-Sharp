﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Tools;

namespace Robotic_Arm_Drawing_Demo
{
    public partial class frm_main : Form
    {
        Drawing_Board_RoboDK rdk;
        Drawing_Board_Csharp cdk;
         
        bool Draw_Enable = false;
        //_______________________________________________________________________________________________________
        public frm_main()
        {
            InitializeComponent();
            cdk = new Drawing_Board_Csharp(panel1);
            rdk= new Drawing_Board_RoboDK(940,2000,panel1.Height,panel1.Width);
        }
        //_______________________________________________________________________________________________________
        private void btn_connect_Click(object sender, EventArgs e)
        {
           if(rdk.connect())
            {
                btn_connect.BackColor = Color.Green;
                txt_msg.Text = "connected OK";            
                txt_robot_pen.Text =rdk.rbt_pen[0] + "," + rdk.rbt_pen[1];
            }
           else
            {
                btn_connect.BackColor = Color.Red;
                txt_msg.Text = "Unable to connect with RoboDK";
            }
        }
        //_______________________________________________________________________________________________________
        private void btn_test_Click(object sender, EventArgs e)
        {
           
        }
        //_______________________________________________________________________________________________________
        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            txt_mousePosX.Text = e.X.ToString();
            txt_mousePosY.Text = e.Y.ToString();

            string posX = ((int)rdk.Get_Cal_X(e.Y)).ToString();
            txt_robot_board_PosX.Text = posX;

            string posY = ((int)rdk.Get_Cal_Y(e.X)).ToString();
            txt_robot_board_PosY.Text = posY;

            string s = posX + "," + posY + ",0,-180,0,0";
            txt_send_string.Text = s;

            if (Draw_Enable)
            {
                cdk.draw(e.X, e.Y);
                rdk.draw(e.Y, e.X, 0);
                rdk.Go_to_Pos(s);
            }
        }
        //_______________________________________________________________________________________________________
        private void Form1_Load(object sender, EventArgs e)
        {
            if (rdk.connect())
            {
                btn_connect.BackColor = Color.Green;
                txt_msg.Text = "connected OK";
                txt_robot_pen.Text = rdk.rbt_pen[0] + "," + rdk.rbt_pen[1];
                btn_connect.Text = "Connected";
            }
            else
            {
                btn_connect.BackColor = Color.Red;
                txt_msg.Text = "Unable to connect with RoboDK";
            }
            txt_Board_Dimension.Text = "X="+panel1.Width.ToString()+", Y="+ panel1.Height.ToString();
            lbl_robot_board_dimension.Text= "X=" + rdk.Robot_Board_X_length.ToString() + ", Y=" + rdk.Robot_Board_Y_Length.ToString();
        }
        //_______________________________________________________________________________________________________
        private void btn_set_colour_Click(object sender, EventArgs e)
        {
            Color c = utilUI.Get_Colour_From_Colour_Picker();
            cdk.set_colour(c);
            rdk.set_colour(c);
        }
        //_______________________________________________________________________________________________________
        private void btn_update_Click(object sender, EventArgs e)
        {

        }
        //_______________________________________________________________________________________________________
        private void btn_clear_Click(object sender, EventArgs e)
        {
            panel1.Invalidate();
            rdk.Clear();
        }
        //_______________________________________________________________________________________________________
        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            decimal x = e.X;
            decimal y = e.Y;

            Draw_Enable = true;
            cdk.clear_point_buffer();
            rdk.clear_point_buffer();
            rdk.push((int)y,(int)x, 0);
        }
        //_______________________________________________________________________________________________________
        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            Draw_Enable = false;
        }

        private void btn_pos_send_Click(object sender, EventArgs e)
        {
            string s = rdk.Go_to_Pos(txt_send_string.Text);
            txt_msg.Text = s;
        }

        private void btn_get_pos_Click(object sender, EventArgs e)
        {
            txt_rbt_pos_string.Text = rdk.Get_Pos();
        }
        //_______________________________________________________________________________________________________









        //_______________________________________________________________________________________________________
    }// class
}// namespace
