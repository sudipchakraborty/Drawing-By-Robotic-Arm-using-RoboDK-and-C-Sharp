﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Data;
using System.Drawing;

using System.Windows.Forms;

namespace Tools
{
    class Drawing_Board_Csharp
    {

        Graphics g;

        public List<string> rbt_pen = new List<string>();
        List<Point> point_Buffer = new List<Point>();
        private int Board_Width;
        private int Board_Height;
        Pen pen;
        //_________________________________________________________________________________________________________
        public Drawing_Board_Csharp(Panel p)
        {
            g = p.CreateGraphics();
            this.Board_Height = p.Height;
            this.Board_Width = p.Width;                       
            pen=new Pen(Color.Black, 3);
        }
        //_________________________________________________________________________________________________________
        public void draw(int posX,int posY)
        {
            Point p = new Point(posX, posY);
            point_Buffer.Add(p);

            if(point_Buffer.Count>1)
            {
                g.DrawLine(pen, point_Buffer[point_Buffer.Count-2], point_Buffer[point_Buffer.Count-1]);
            }
        }
        //_________________________________________________________________________________________________________
        public void set_colour(Color c)
        {       
            pen.Color = c;
        }
        //_________________________________________________________________________________________________________
        public void clear_point_buffer()
        {
            point_Buffer.Clear();
        }
        //_________________________________________________________________________________________________________
      











    }// class
}// namespace
