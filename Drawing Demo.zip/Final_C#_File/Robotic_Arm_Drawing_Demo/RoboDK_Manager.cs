﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

using Tools;

namespace Tools
{
    class RoboDK_Manager
    {
        IP_Client channel = new IP_Client();

        public string api;
        public UInt32 api_version;
        public UInt32 build;
        public UInt64 itemId;
        public UInt64 robot_type;
        public string Robot_Name;
        public double[] angle = new double[6];
        public double Tx, Ty, Tz, Rx, Ry, Rz;
        public string str_Pos;

        public string LastStatusMessage;
        public bool connected = false;
        //---------------------------------------------------------
        public enum ItemType 
        {
            ITEM_TYPE_NONE = 0,
            ITEM_TYPE_STATION = 1,
            ITEM_TYPE_ROBOT = 2,
            ITEM_TYPE_FRAME = 3,
            ITEM_TYPE_TOOL = 4,
            ITEM_TYPE_OBJECT = 5,
            ITEM_TYPE_TARGET = 6,
            ITEM_TYPE_PROGRAM = 8,
            ITEM_TYPE_INSTRUCTION = 9,
            ITEM_TYPE_PROGRAM_PYTHON = 10,
            ITEM_TYPE_MACHINING = 11,
            ITEM_TYPE_BALLBARVALIDATION = 12,
            ITEM_TYPE_CALIBPROJECT = 13,
            ITEM_TYPE_VALID_ISO9283 = 14,
            ITEM_TYPE_FOLDER = 17,
            ITEM_TYPE_ROBOT_ARM = 18,
            ITEM_TYPE_CAMERA = 19,
            ITEM_TYPE_GENERIC = 20,
            ITEM_TYPE_ROBOT_AXES = 21
        };
        //---------------------------------------------------------
        public enum MoveType
        {
            Invalid = -1,
            Joint = 1,
            Linear = 2,
            Circular = 3
        };
        //---------------------------------------------------------
       public enum projection_types
        {
            PROJECTION_NONE = 0,                // # No curve projection
            PROJECTION_CLOSEST = 1,             // # The projection will be the closest point on the surface
            PROJECTION_ALONG_NORMAL = 2,        // # The projection will be done along the normal.
            PROJECTION_ALONG_NORMAL_RECALC = 3, // # The projection will be done along the normal. Furthermore, the normal will be recalculated according to the surface normal.
            PROJECTION_CLOSEST_RECALC = 4,      // # The projection will be the closest point on the surface and the normals will be recalculated
            PROJECTION_RECALC = 5               // # The normals are recalculated according to the surface normal of the closest projection. The points are not changed.
        }
        //---------------------------------------------------------


        //__________________________________________________________________________________________________________________
        public RoboDK_Manager()
        {
        }
        //______________________________________________________________________________________________________________________
        public bool connected_With_RoboDK()
        {
            channel.connect("127.0.0.1", 20500);
            if (channel.connected)
            {
                if (connection_verified())
                {
                    Read_Robot_Details();
                    connected = true;
                    return true;
                }
                else
                {
                    connected = false;
                    return false;

                }
            }
            else
            {
                return false;
            }
        }
        //____________________________________________________________________________________________________________________



        //_______________________________________________________________________________________________________________________
        private bool connection_verified()
        {
            channel.clear_buffer();
            channel.push("RDK_API\n");
            int i = 0;
            channel.push_with_reverse(i);
            channel.send();
            this.api = channel.read_line();
            this.api_version = channel.read_int();
            this.build = channel.read_int();

           UInt32 st= Read_status();

            if ((this.api == "RDK_API")&& (st==0))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        //__________________________________________________________________________________________
        public double[,] SolveFK(string Id, double[] joints)
        {
            double itemId = Convert.ToDouble(Id);
            channel.Poll();
            channel.clear_buffer();
            channel.push("G_FK\n");
            int i = joints.Count();
            channel.push_with_reverse(i);
            channel.push_Array(joints);
            channel.push_with_reverse((long)itemId);
            channel.send();
            byte[] joint_buffer = channel.read_Bytes(16*8);
            double[,] mat = Get_Matrix(joint_buffer);
            string s= Read_status_str();

            return mat;
           

            //double[] d = ToTxyzRxyz(mat);
            //Tx = d[0];
            //Ty = d[1];
            //Tz = d[2];
            //Rx = d[3];
            //Ry = d[4];
            //Rz = d[5];
            //str_Pos = Values_2_String(d);
            //return str_Pos;





            //UInt32 no_of_joints = channel.read_int();

            //int J_count = joints.Count(); // push no. of joints
            //channel.push_with_reverse(J_count);

            //for (var i = 0; i < J_count; i++)
            //{
            //    channel.push_with_reverse(joints[i]);
            //}



            //byte[] joint_buffer = channel.read_Bytes((UInt16)(8 * no_of_joints));
            //Read_status();

            //byte[] temp = new byte[8];

            //for (int i = 0; i < no_of_joints; i++)
            //{
            //    Array.Copy(joint_buffer, i * 8, temp, 0, 8);
            //    Array.Reverse(temp);
            //    angle[i] = BitConverter.ToDouble(temp, 0);
            //}
            //    command = 'G_FK'
            //self.link._send_line(command)
            //self.link._send_array(joints)
            //self.link._send_item(self)
            //pose = self.link._rec_pose()
            //self.link._check_status()
            //if tool is not None:
            //    pose = pose * tool
            //if reference is not None:
            //    pose = robodk.invH(reference) * pose
            //return pose
        }

        public string read_joints()
        {
            channel.Poll();
            channel.clear_buffer();
            channel.push("G_Thetas\n");
            channel.push_with_reverse((long)itemId);
            channel.send();
            UInt32 no_of_joints = channel.read_int();
            byte[] joint_buffer = channel.read_Bytes((UInt16)(8*no_of_joints));
            Read_status();

            byte[] temp = new byte[8];

            for (int i = 0; i < no_of_joints; i++)
            {
                Array.Copy(joint_buffer, i*8, temp, 0, 8);
                Array.Reverse(temp);
                angle[i] = BitConverter.ToDouble(temp, 0);
            }

            string s = "J1=" + angle[0].ToString() +", "+
                     "J2=" + angle[1].ToString() + ", " +
                     "J3=" + angle[2].ToString() + ", " +
                     "J4=" + angle[3].ToString() + ", " +
                     "J5=" + angle[4].ToString() + ", " +
                     "J6=" + angle[5].ToString();
            return s;
        }
        //_______________________________________________________________________________________________________________________
        public string read_joints2()
        {
            channel.Poll();
            channel.clear_buffer();
            channel.push("G_Thetas\n");
            channel.push_with_reverse((long)itemId);
            channel.send();
            UInt32 no_of_joints = channel.read_int();
            byte[] joint_buffer = channel.read_Bytes((UInt16)(8 * no_of_joints));
            Read_status();

            byte[] temp = new byte[8];

            for (int i = 0; i < no_of_joints; i++)
            {
                Array.Copy(joint_buffer, i * 8, temp, 0, 8);
                Array.Reverse(temp);
                angle[i] = BitConverter.ToDouble(temp, 0);
            }

            string s =angle[0].ToString() + ", " +
                     angle[1].ToString() + ", " +
                     angle[2].ToString() + ", " +
                     angle[3].ToString() + ", " +
                     angle[4].ToString() + ", " +
                     angle[5].ToString();
            return s;
        }
        //_______________________________________________________________________________________________________________________
        public string Get_Pose(string iid)
        {
            double itemId = Convert.ToDouble(iid);
            channel.Poll();
            channel.clear_buffer();
            channel.push("G_Hlocal\n");
            channel.push_with_reverse((long)itemId);
            channel.send();
            byte[] joint_buffer = channel.read_Bytes(128);
            Read_status();
            double[,] mat = Get_Matrix(joint_buffer);

            double[] d = ToTxyzRxyz(mat);
            Tx = d[0];
            Ty = d[1];
            Tz = d[2];
            Rx = d[3];
            Ry = d[4];
            Rz = d[5];
            str_Pos = Values_2_String(d);
            return str_Pos;
        }
        //___________________________________________________________________________________________________________________     
        public string read_Pose()
        {
            channel.Poll();
            channel.clear_buffer();
            channel.push("G_Hlocal\n");
            channel.push_with_reverse((long)itemId);
            channel.send();
            byte[] joint_buffer = channel.read_Bytes(128);
            Read_status();
            double[,] mat= Get_Matrix(joint_buffer);

            double[] d = ToTxyzRxyz(mat);
            Tx = d[0];
            Ty = d[1];
            Tz = d[2];
            Rx = d[3];
            Ry = d[4];
            Rz = d[5];
            str_Pos = Values_2_String(d);
            return str_Pos;
        }
 //___________________________________________________________________________________________________________________     
        public double[,] setPos(string id)
        {
            double itemId = Convert.ToDouble(id);
            channel.Poll();
            channel.clear_buffer();
            channel.push("G_Hlocal\n");
            channel.push_with_reverse((long)itemId);
            channel.send();
            byte[] joint_buffer = channel.read_Bytes(128);
            Read_status();
            double[,] mat = Get_Matrix(joint_buffer);
            return mat;
        }
        //____________________________________________________________________________________________________________________
        public double[,] setPos(double[,] _mat, double x, double y, double z)
        {
            _mat[0, 3] = x;
            _mat[1, 3] = y;
            _mat[2, 3] = z;
            return _mat;
        }
        //__________________________________________________________________________________________________________________________
        public double[,] setPos(double[,] _mat, double[] xyz)
        {
            //if (!Is4x4() || xyz.Length < 3)
            //    return;
            _mat[0, 3] = xyz[0];
            _mat[1, 3] = xyz[1];
            _mat[2, 3] = xyz[2];
            return _mat;
        }
        //__________________________________________________________________________________________________________________________
        public string setPos(double[,] mat, string id)
        {
            double itemId = Convert.ToDouble(id);
            channel.Poll();
            channel.clear_buffer();
            channel.push("S_Hlocal\n");
            channel.push_with_reverse((long)itemId);
            double[] mat_send = ToDoubles(mat);
            byte[] b = channel.Get_Bytes_From_Double_Array(mat_send);
            channel.push(b);
            channel.send();
            string s = Read_status_str();
            return s;
        }
        //__________________________________________________________________________________________________________________________
        public string setVisible(string id, bool visible, bool visible_frame= false)
        {
            double itemId = Convert.ToDouble(id);
            channel.Poll();
            channel.clear_buffer();
            channel.push("S_Visible\n");
            channel.push_with_reverse((long)itemId);

            int i = 0;
            if (visible) i =1; else i= 0;
            channel.push_with_reverse(i);

            if (visible_frame) i = 1; else i = 0;
            channel.push_with_reverse(i);

            channel.send();
            string s = Read_status_str();
            return s;
        }
        //___________________________________________________________________________________________________________________
        public string setName(string id, string name)
        {
            double itemId = Convert.ToDouble(id);
            channel.Poll();
            channel.clear_buffer();
            channel.push("S_Name\n");
            channel.push_with_reverse((long)itemId);
            channel.push(name+"\n");
            channel.send();
            string s = Read_status_str();
            return s;
        }
        //___________________________________________________________________________________________________________________
        public string Scale(string id, double size)
        {
            double itemId = Convert.ToDouble(id);
            channel.Poll();
            channel.clear_buffer();
            channel.push("Scale\n");
            channel.push_with_reverse((long)itemId);

            double[] d = new double[] { size, size, size };
            channel.push_Array2(d);
            channel.send();
            string s = Read_status_str();
            return s;
        }
        //___________________________________________________________________________________________________________________
        public string Scale(string id,double x, double y, double z)
        {
            double itemId = Convert.ToDouble(id);
            channel.Poll();
            channel.clear_buffer();
            channel.push("Scale\n");
            channel.push_with_reverse((long)itemId);

            int i = 3;
            channel.push_with_reverse(i);

            channel.push_with_reverse(x);
            channel.push_with_reverse(y);
            channel.push_with_reverse(z);


            channel.send();
            string s = Read_status_str();
            return s;
        }
        //___________________________________________________________________________________________________________________
        public double[,] Draw_Line(string id) 
        {
            double itemId = Convert.ToDouble(id);
            channel.Poll();
            channel.clear_buffer();
            channel.push("G_Hlocal\n");
            channel.push_with_reverse((long)itemId);
            channel.send();
            byte[] joint_buffer = channel.read_Bytes(128);
            Read_status();
            double[,] mat = Get_Matrix(joint_buffer);
            return mat;
        }













        public List<string> AddPoints(string id, List<double[]> curve_points, bool add_to_ref = false, int projection_type = (int)projection_types.PROJECTION_ALONG_NORMAL_RECALC)        //CURVE, False, PROJECTION_ALONG_NORMAL_RECALC)
        {
            double itemId = Convert.ToDouble(id);
            channel.Poll();
            channel.clear_buffer();
            channel.push("AddWire\n");                              //    self._send_line(command)          

            //channel.push_matrix(curve_points);

            int i = 6; channel.push_with_reverse(i);
            i = 2; channel.push_with_reverse(i);

            byte[] b = new byte[96];
            for(int p=0;p<b.Length;p++)
            {
                b[p] = 0x00;
            }

            b[48] = (byte)'@';
            b[49] = (byte)'Y';
            channel.push(b);
            
            
            channel.push_with_reverse((long)itemId);                      //self._send_item(reference_object)
            i = 0; channel.push_with_reverse(i);                //self._send_int(1 if add_to_ref else 0)
            i = projection_type; channel.push_with_reverse(i);      //self._send_int(projection_type)
            channel.send();

            List<string> Item = new List<string>();
            double Itm = channel.read_double();
            UInt32 rbt_type = channel.read_int();

            string s = Read_status_str();

            Item.Add(Itm.ToString());
            Item.Add(rbt_type.ToString());

            return Item;
        }
       
        
        // if isinstance(points, list) :
        //    points = robodk.Mat(points).tr()


        //elif not isinstance(points, robodk.Mat) :
        //    raise Exception("points must be a 3xN or 6xN list or matrix")
        //self._check_connection()
        //command = 'AddPoints'
        //self._send_line(command)
        //self._send_matrix(points)
        //self._send_item(reference_object)
        //self._send_int(1 if add_to_ref else 0)
        //self._send_int(projection_type)
        //newitem = self._rec_item()
        //self._check_status()
        //return newitem







        //___________________________________________________________________________________________________________________
        public List<string> AddCurve(string id, List<double[]> curve_points, bool add_to_ref=false, int projection_type=(int)projection_types.PROJECTION_ALONG_NORMAL_RECALC)        //CURVE, False, PROJECTION_ALONG_NORMAL_RECALC)
        {
            double itemId = Convert.ToDouble(id);
            channel.Poll();
            channel.clear_buffer();
            channel.push("AddWire\n");                              //    self._send_line(command)          

             channel.push_matrix(curve_points);
            //int i = 6; channel.push_with_reverse(i);
            //i = 2; channel.push_with_reverse(i);

            //byte[] b = new byte[96];
            //for (int p = 0; p < b.Length; p++)
            //{
            //    b[p] = 0x00;
            //}

            //b[48] = (byte)'@';
            //b[49] = (byte)'Y';
            //channel.push(b);

            







            channel.push_with_reverse((long)itemId);                      //self._send_item(reference_object)
            int i = 0; channel.push_with_reverse(i);                //self._send_int(1 if add_to_ref else 0)
            i = projection_type; channel.push_with_reverse(i);      //self._send_int(projection_type)
            channel.send();

            List<string> Item = new List<string>();
            double Itm= channel.read_double();
            UInt32 rbt_type = channel.read_int();

            string s = Read_status_str();

            Item.Add(Itm.ToString());
            Item.Add(rbt_type.ToString());
            
            return Item;
        }
        //___________________________________________________________________________________________________________________
       public List<string> AddShape(List<double[]> triangle_points, double add_to= 0, bool override_shapes = false)
        {
            List<string> Item = new List<string>();

            channel.clear_buffer();
            channel.push("AddShape2\n");
            channel.push_matrix(triangle_points);
            channel.push_with_reverse((long)add_to);
            channel.push(Convert.ToInt32(override_shapes));
            channel.send();

            double itemId = channel.read_double();
            UInt32 robot_type = channel.read_int();
            Item.Add(itemId.ToString());
            Item.Add(robot_type.ToString());

            var st = Read_status_str();
            return Item;
        }
        //___________________________________________________________________________________________________________________
         public double[,] Get_Matrix(byte[] src)
        {
            int Cols = 4;
            int Rows = 4;
            double[,] pose = new double[Rows, Cols];
            byte[] temp = new byte[8];

            var cnt = 0;
            for (var j = 0; j < Cols; j++)
            {
                for (var i = 0; i < Rows; i++)
                {
                    Array.Copy(src, cnt, temp, 0, 8);
                    Array.Reverse(temp);
                    double d=BitConverter.ToDouble(temp, 0);
                    pose[i, j] = d;
                    cnt += sizeof(double);
                }
            }
            return pose;
        }
        //_________________________________________________________________________________________________________________________
        public double[] ToTxyzRxyz(double [,]_mat)
        {
            var xyzwpr = new double[6];
            var x = _mat[0, 3];
            var y = _mat[1, 3];
            var z = _mat[2, 3];
            double rx1 = 0;
            double ry1 = 0;
            double rz1 = 0;


            var a = _mat[0, 0];
            var b = _mat[0, 1];
            var c = _mat[0, 2];
            var d = _mat[1, 2];
            var e = _mat[2, 2];

            if (c == 1)
            {
                ry1 = 0.5 * Math.PI;
                rx1 = 0;
                rz1 = Math.Atan2(_mat[1, 0], _mat[1, 1]);
            }
            else if (c == -1)
            {
                ry1 = -Math.PI / 2;
                rx1 = 0;
                rz1 = Math.Atan2(_mat[1, 0], _mat[1, 1]);
            }
            else
            {
                var sy = c;
                var cy1 = +Math.Sqrt(1 - sy * sy);

                var sx1 = -d / cy1;
                var cx1 = e / cy1;

                var sz1 = -b / cy1;
                var cz1 = a / cy1;

                rx1 = Math.Atan2(sx1, cx1);
                ry1 = Math.Atan2(sy, cy1);
                rz1 = Math.Atan2(sz1, cz1);
            }

            xyzwpr[0] = x;
            xyzwpr[1] = y;
            xyzwpr[2] = z;
            xyzwpr[3] = rx1 * 180.0 / Math.PI;
            xyzwpr[4] = ry1 * 180.0 / Math.PI;
            xyzwpr[5] = rz1 * 180.0 / Math.PI;
            return xyzwpr;
        }
        //________________________________________________________________________________________________________________________
        public string Values_2_String(double[] dvalues)
        {
            if (dvalues == null || dvalues.Length < 1) return "Invalid values";
            // Not supported on .NET Framework 2.0:
            //string strvalues = String.Join(" , ", dvalues.Select(p => p.ToString("0.0")).ToArray());
            var strvalues = dvalues[0].ToString("0.0");
            for (var i = 1; i < dvalues.Length; i++) strvalues += $" , {dvalues[i]:0.0}";

            return strvalues;
            //return "";
        }
        //________________________________________________________________________________________________________________________
        public void Read_Robot_Details()
        {
            channel.clear_buffer();
            channel.push("PickItem\n");
            channel.push("Select a robot\n");
            int i = 2; //RoboDk.API.Model.ItemType.Robot
            channel.push_with_reverse(i);
            channel.send();
            this.itemId = channel.read_double();
            this.robot_type = channel.read_int();
            Read_status();
            Read_Robot_Name();
        }
        //____________________________________________________________________________________________________________________
        public List<string> Get_Robot_Details()
        {
            List<string> Item = new List<string>();
            channel.clear_buffer();
            channel.push("PickItem\n");
            channel.push("Select a robot\n");
            int i = 2; //RoboDk.API.Model.ItemType.Robot
            channel.push_with_reverse(i);
            channel.send();
            Item.Add(channel.read_double().ToString());
            Item.Add(channel.read_int().ToString());
            Read_status();
            Read_Robot_Name();
            return Item;
        }
        //____________________________________________________________________________________________________________________
        public List<string> ItemUserPick(string message,int itemtype)
        {
            List<string> Item = new List<string>();
            
            channel.clear_buffer();
            channel.push("PickItem\n");
            channel.push("\n");
            int i = itemtype;
            channel.push_with_reverse(i);
            channel.send();
            double itemId = channel.read_double();
            uint robot_type = channel.read_int();
            Read_status();

            Item.Add(itemId.ToString());
            Item.Add(robot_type.ToString());
            return Item;
            
        }
        //____________________________________________________________________________________________________________________
        public List<string> Item(string Item_Name, int itemtype)
        {
            List<string> Item = new List<string>();
            channel.clear_buffer();
            channel.Poll();

            if (itemtype == (int)ItemType.ITEM_TYPE_NONE)
            {
                channel.push("G_Item\n");
                channel.push(Item_Name + "\n");
            }
            else
            {
                channel.push("G_Item2\n");
                channel.push(Item_Name + "\n");
                channel.push_with_reverse(itemtype);
            }
            channel.send();
            double itemId = channel.read_double();
            uint robot_type = channel.read_int();
            Read_status();

            Item.Add(itemId.ToString());
            Item.Add(robot_type.ToString());
            return Item;
        }
        //____________________________________________________________________________________________________________________
        public string Delete(double itemId)
        {
            channel.clear_buffer();
            channel.push("RemoveLst\n");
            int i =1;
            channel.push_with_reverse(i);
            channel.push_with_reverse((long)itemId);
            channel.send();
            string st = Read_status_str();
            return st;
        }
        //____________________________________________________________________________________________________________________
        public string Delete(string id)
        {
            double itemId = Convert.ToDouble(id);
            channel.clear_buffer();
            channel.push("Remove\n");
            channel.push_with_reverse((long)itemId);
            channel.send();
            string st = Read_status_str();
            return st;
        }
        //____________________________________________________________________________________________________________________
        public string Copy(string id, int copy_childs)
        {
            double itemId = Convert.ToDouble(id);
            channel.clear_buffer();
            channel.push("Copy2\n");
            channel.push_with_reverse((long)itemId);
            channel.push_with_reverse(copy_childs);
            channel.send();
            var st = Read_status_str();
            return st;
        }
        //____________________________________________________________________________________________________________________
        public string Copy(double itemId, int copy_childs)
        {
            channel.clear_buffer();
            channel.push("Copy2\n");
            channel.push_with_reverse((long)itemId);
            channel.push_with_reverse(copy_childs);
            channel.send();
            var st = Read_status_str();
            return st;
        }
        //____________________________________________________________________________________________________________________
        public string Recolor(string id)
        {
            double itemId = Convert.ToDouble(id);
            channel.clear_buffer();
            channel.push("Recolor\n");
            channel.push_with_reverse((long)itemId);
            channel.push_with_reverse((int)9);

            double[]cr= new double[9];
            // tolerence
            cr[0] = 0;
            // from colour
            cr[1] = 0;
            cr[2] = 0;
            cr[3] = 0;
            cr[4] = 0;
            // to colour
            cr[5] = 0.835;
            cr[6] = 0.0788;
            cr[7] = 0.0;
            cr[8] = 1;

            channel.push_Array(cr);

            channel.send();
            var st = Read_status_str();
            return st;
        }
        //____________________________________________________________________________________________________________________
        public string setValue(string id, string varname, string value)
        {
            double itemId = Convert.ToDouble(id);
            channel.clear_buffer();
            channel.push("S_Gen_Str\n");
            channel.push(itemId);
            channel.push(varname+"\n");
            channel.push(value + "\n");

            channel.send();
            var st = Read_status_str();
            return st;

        }
        //____________________________________________________________________________________________________________________
        public string setColorCurve(string id,Color c)
        {
            double itemId = Convert.ToDouble(id);
            channel.clear_buffer();
            channel.push("S_CurveColor\n");
            channel.push_with_reverse((long)itemId);
            channel.push_with_reverse((int)(-1));

            double[] cr = new double[4];

           // var v = utilUI.Get_ARGB_from_Colour(c);
            cr[0] = c.R;
            cr[1] = c.G;
            cr[2] = c.B;
            cr[3] = c.A;

            channel.push_with_reverse((int)(4));
            channel.push_Array(cr);

            channel.send();
            var st = Read_status_str();
            return st;
        }
        //____________________________________________________________________________________________________________________   
        public List<string> Paste(string id)
        {
            List<string> Item = new List<string>();
            double itemId = Convert.ToDouble(id);

            channel.clear_buffer();
            channel.push("Paste\n");
            channel.push_with_reverse((long)itemId);
            channel.send();
            double _itemId = channel.read_double();
            uint robot_type = channel.read_int();
            var st = Read_status();

            Item.Add(itemId.ToString());
            Item.Add(robot_type.ToString());
            return Item;
        }
        //____________________________________________________________________________________________________________________
        public double[] JointsHome(double itemId)
        {         
            channel.clear_buffer();
            channel.push("G_Home\n");
            channel.push_with_reverse(itemId);
            channel.send();

            UInt32 no_of_joints = channel.read_int();
            double[] joints = new double[no_of_joints];

            byte[] joint_buffer = channel.read_Bytes((UInt16)(8 * no_of_joints));
            var v=Read_status();

            byte[] temp = new byte[8];

            for (int i = 0; i < no_of_joints; i++)
            {
                Array.Copy(joint_buffer, i * 8, temp, 0, 8);
                Array.Reverse(temp);
                joints[i] = BitConverter.ToDouble(temp, 0);
            }
            return joints;
        }
        //________________________________________________________________________________________________________________________
        public void Read_Robot_Name()
        {
            channel.clear_buffer();
            channel.push("G_Name\n");
            channel.push_with_reverse(itemId);
            channel.send();
            this.Robot_Name= channel.read_line();
            Read_status();
        }
        //____________________________________________________________________________________________________________________
        public void Type(double itemId)
        {
            channel.Poll();
            channel.clear_buffer();
            channel.push("G_Item_Type\n");
            channel.push_with_reverse((long)itemId);
            channel.send();
            UInt32 _type = channel.read_int();
            var st= Read_status();
        }
        //____________________________________________________________________________________________________________________
        public UInt32 Read_status()
        {
           int status=(int) channel.read_int();

            switch (status)
            {
                case 0:
                    LastStatusMessage = "OK";
                    return 0 ;

                case 1:
                    LastStatusMessage = "Invalid item provided: The item identifier provided is not valid or it does not exist.";
                    break;
                case 2:
                    {
                        LastStatusMessage =channel.read_line();
                    }
                    break;
                case 3:
                        // output error
                        LastStatusMessage = channel.read_line();
                    break;

                case 9:
                        LastStatusMessage = "Invalid license. Contact us at: info@robodk.com";
                     break;

                case 10:
                        // Target reach error
                        LastStatusMessage = channel.read_line();
                    break;

                case 11:
                        // Stopped by user
                        LastStatusMessage = channel.read_line();
                        break;
                case 12:
                        // Invalid input exception
                        LastStatusMessage = channel.read_line();
                    break;

                default:
                        if (status > 0 && status < 100)
                        {
                            LastStatusMessage =channel.read_line();
                        }
                        else
                        {
                            //raise Exception('Problems running function');
                            LastStatusMessage = "Unknown problem running RoboDK API function";
                        }
                    break;
            }
            return Convert.ToUInt32(status);
        }
        //____________________________________________________________________________________________________________________
        public string Read_status_str()
        {
            int status = (int)channel.read_int();
            string ret_str = "";
            switch (status)
            {
                case 0:
                    ret_str="OK";
                    break;

                case 1:
                    ret_str = "Invalid item provided: The item identifier provided is not valid or it does not exist.";
                    break;
                case 2:
                    {
                        ret_str = channel.read_line();
                    }
                    break;
                case 3:
                    // output error
                    ret_str = channel.read_line();
                    break;

                case 9:
                    ret_str = "Invalid license. Contact us at: info@robodk.com";
                    break;

                case 10:
                    // Target reach error
                    ret_str = channel.read_line();
                    break;

                case 11:
                    // Stopped by user
                    ret_str = channel.read_line();
                    break;
                case 12:
                    // Invalid input exception
                    ret_str = channel.read_line();
                    break;

                default:
                    if (status > 0 && status < 100)
                    {
                        ret_str = channel.read_line();
                    }
                    else
                    {
                        //raise Exception('Problems running function');
                        ret_str = "Unknown problem running RoboDK API function";
                    }
                    break;
            }
            return ret_str;
        }
        //____________________________________________________________________________________________________________________
        public string update_Single_Joint(string str_val, int joint, string value)
        {
            string str_send = "";
            string[] s = str_val.Split(',');
            s[joint] = value;

            for(int i=0;i<s.Count();i++)
            {
                str_send = str_send + s[i] + ",";
            }

            str_send = str_send.Substring(0, str_send.Length - 1);
            Move_Joints(str_send);
            return str_send;
        }
        //____________________________________________________________________________________________________________________
        public void Move_Joints(string strvalues)
        {
            double[] joints = String_2_Values(strvalues);
            
            channel.clear_buffer();
            channel.push("MoveX\n");
            int m = 1; // move_type
            channel.push_with_reverse(m);
            channel.push_with_reverse(1);

            int J_count = joints.Count(); // push no. of joints
            channel.push_with_reverse(J_count);

            for (var i = 0; i < J_count; i++)
            {
                channel.push_with_reverse(joints[i]);
            }

            UInt64 id = 0;
           channel.push_with_reverse(id);
            channel.push_with_reverse((long)itemId);
            channel.send();
            Read_status();           
        }
        //____________________________________________________________________________________________________________________
        public double[] String_2_Values(string strvalues)
        {
            double[] dvalues = null;
            try
            {
                dvalues = Array.ConvertAll(strvalues.Split(','), double.Parse);
            }
            catch (FormatException ex)
            {
                string s = $@"Invalid input: {strvalues}: {ex.Message}";
            }

            return dvalues;
        }
        //____________________________________________________________________________________________________________________
        public string update_Single_pos(string str_val, int pos, string value)
        {
            string str_send = "";
            string[] s = str_val.Split(',');
            s[pos] = value;

            for (int i = 0; i < s.Count(); i++)
            {
                str_send = str_send + s[i] + ",";
            }

            str_send = str_send.Substring(0, str_send.Length - 1);
            Move_pos(str_send);
            return str_send;
        }
        //____________________________________________________________________________________________________________________
        public void Move_pos(string strvalues)
        {
            double[] xyzwpr = String_2_Values(strvalues);
            double[,] mat = FromTxyzRxyz(xyzwpr[0], xyzwpr[1], xyzwpr[2], xyzwpr[3], xyzwpr[4], xyzwpr[5]);
            double[] mat_send = ToDoubles(mat);

            channel.clear_buffer();
            channel.push("MoveX\n");
            int m = 1; // move_type
            channel.push_with_reverse(m);
            m = 2;
            channel.push_with_reverse(m);

            int J_count = 16; //
            channel.push_with_reverse(J_count);

            for (var i = 0; i < J_count; i++)
            {
                channel.push_with_reverse(mat_send[i]);
            }

            UInt64 id = 0;
            channel.push_with_reverse(id);
            channel.push_with_reverse((long)itemId);
            channel.send();
            Read_status();
        }
        //__________________________________________________________________________________________________________________________
        public string Move_pos(string iid, string strvalues)
        {
            double itemId = Convert.ToDouble(iid);
            double[] xyzwpr = String_2_Values(strvalues);
            double[,] mat = FromTxyzRxyz(xyzwpr[0], xyzwpr[1], xyzwpr[2], xyzwpr[3], xyzwpr[4], xyzwpr[5]);
            double[] mat_send = ToDoubles(mat);

            channel.clear_buffer();
            channel.push("MoveX\n");
            int m = 1; // move_type
            channel.push_with_reverse(m);
            m = 2;
            channel.push_with_reverse(m);

            int J_count = 16; //
            channel.push_with_reverse(J_count);

            for (var i = 0; i < J_count; i++)
            {
                channel.push_with_reverse(mat_send[i]);
            }

            UInt64 id = 0;
            channel.push_with_reverse(id);
            channel.push_with_reverse((long)itemId);
            channel.send();
            string s = Read_status_str();
            return s;
        }
        //__________________________________________________________________________________________________________________________
        public double[] ToDoubles(double[,] _mat)
        {
            int _rows = 4;
            int _cols = 4;

            var cnt = 0;
            var array = new double[_rows * _cols];
            for (var j = 0; j < _cols; j++)
                for (var i = 0; i < _rows; i++)
                {
                    array[cnt] = _mat[i, j];
                    cnt = cnt + 1;
                }
            return array;
        }
        //__________________________________________________________________________________________________________________________
        public double[,] FromTxyzRxyz(double x, double y, double z, double rx, double ry, double rz)
        {
            var a = rx * Math.PI / 180.0;
            var b = ry * Math.PI / 180.0;
            var c = rz * Math.PI / 180.0;
            var crx = Math.Cos(a);
            var srx = Math.Sin(a);
            var cry = Math.Cos(b);
            var sry = Math.Sin(b);
            var crz = Math.Cos(c);
            var srz = Math.Sin(c);
            double[,] d= Get_Matrix(cry * crz, -cry * srz, sry, x, crx * srz + crz * srx * sry, crx * crz - srx * sry * srz,
                -cry * srx, y, srx * srz - crx * crz * sry, crz * srx + crx * sry * srz, crx * cry, z);
            return d;     
        }
        //__________________________________________________________________________________________________________________________
        public double[,] Get_Matrix(double nx, double ox, double ax, double tx, double ny, double oy, double ay, double ty, double nz,double oz, double az, double tz) // Matrix Class constructor
        {
            int _rows = 4;
            int _cols = 4;
            double[,] _mat = new double[_rows, _cols];
            
            _mat[0, 0] = nx;
            _mat[1, 0] = ny;
            _mat[2, 0] = nz;
            _mat[0, 1] = ox;
            _mat[1, 1] = oy;
            _mat[2, 1] = oz;
            _mat[0, 2] = ax;
            _mat[1, 2] = ay;
            _mat[2, 2] = az;
            _mat[0, 3] = tx;
            _mat[1, 3] = ty;
            _mat[2, 3] = tz;
            _mat[3, 0] = 0.0;
            _mat[3, 1] = 0.0;
            _mat[3, 2] = 0.0;
            _mat[3, 3] = 1.0;

             return _mat;
        }
        //__________________________________________________________________________________________________________________________
        public static double[,] ZeroMatrix(int iRows, int iCols) // Function generates the zero matrix
        {
            double[,] matrix = new double[iRows, iCols];
            for (var i = 0; i < iRows; i++)
                for (var j = 0; j < iCols; j++)
                    matrix[i, j] = 0;
            return matrix;
        }
        //__________________________________________________________________________________________________________________________
        public static double [,] IdentityMatrix(int iRows, int iCols) // Function generates the identity matrix
        {
            var matrix = ZeroMatrix(iRows, iCols);
            for (var i = 0; i < Math.Min(iRows, iCols); i++)
                matrix[i, i] = 1;
            return matrix;
        }
        //__________________________________________________________________________________________________________________________
        public static double[,] Identity4x4()
        {
            return IdentityMatrix(4, 4);
        }
        //__________________________________________________________________________________________________________________________
        public static double[,] Transpose(double[,] m) // Matrix transpose, for any rectangular matrix
        {
            int _cols = 4;
            int _rows = 4;

            double[,] t = new double[_cols,_rows];
            for (var i = 0; i < _rows; i++)
                for (var j = 0; j < _cols; j++)
                    t[j, i] = m[i, j];
            return t;
        }
        //__________________________________________________________________________________________________________________________
        public double[,] MultiplyMatSimple(double[,] m1, double[,] m2)
        {
            int _rows = 4;
            int _cols = 4;

            var result = ZeroMatrix(_rows,_cols);
            for (var i = 0; i < _rows; i++)
                for (var j = 0; j < _cols; j++)
                    for (var k = 0; k <_cols; k++)
                        result[i, j] += m1[i, k] * m2[k, j];
            return result;
        }
        //__________________________________________________________________________________________________________________________
        public double[,] transl(double x, double y, double z)
        {
            var mat = IdentityMatrix(4, 4);
            setPos(mat,x, y, z);
            return mat;
        }
        //__________________________________________________________________________________________________________________________
        public  double[,] rotx(double rx)
        {
            var cx = Math.Cos(rx);
            var sx = Math.Sin(rx);
            return  Get_Matrix(1, 0, 0, 0, 0, cx, -sx, 0, 0, sx, cx, 0);
        }
        //__________________________________________________________________________________________________________________________
        public double[,] roty(double ry)
        {
            var cy = Math.Cos(ry);
            var sy = Math.Sin(ry);
            var v= Get_Matrix(cy, 0, sy, 0, 0, 1, 0, 0, -sy, 0, cy, 0);
            return v;
        }
        //__________________________________________________________________________________________________________________________
        public double[,] rotz(double rz)
        {
            var cz = Math.Cos(rz);
            var sz = Math.Sin(rz);
            return  Get_Matrix(cz, -sz, 0, 0, sz, cz, 0, 0, 0, 0, 1, 0);
        }
        //__________________________________________________________________________________________________________________________
        public string _moveX(double[,] target, string  iid, int movetype, bool blocking) 
        {
            double itemId = Convert.ToDouble(iid);
            channel.clear_buffer();

            if (blocking == true){
                channel.push("MoveXb\n");
            }else{
                channel.push("MoveX\n");
            }

            int m = movetype;  
            channel.push_with_reverse(m);

            m = 2;
            channel.push_with_reverse(m);

            int J_count = 16; //
            channel.push_with_reverse(J_count);

            double[] mat_send = ToDoubles(target);

            for (var i = 0; i < J_count; i++)
            {
                channel.push_with_reverse(mat_send[i]);
            }
            UInt64 id = 0;
            channel.push_with_reverse(id);
            channel.push_with_reverse(itemId);
            channel.send();
            string s= Read_status_str();
            return s;
        }
        //__________________________________________________________________________________________________________________________
        public void draw_Point(string _fromitem, string i_id, double x,double y, double z)
        {
            var mmm = transl(x, y, z);
            //   var nnn = rdk.rotz(Math.Atan2(my_ViX[kk], my_ViY[kk]));
            //   var pt_pose = rdk.MultiplyMatSimple(mmm, nnn);
            AddGeometry(_fromitem, i_id, mmm);
        }
        //__________________________________________________________________________________________________________________________
        public void draw_Point(string _fromitem, string i_id, double[] pt)
        {
            var mmm = transl(pt[0], pt[1], pt[2]);
            //   var nnn = rdk.rotz(Math.Atan2(my_ViX[kk], my_ViY[kk]));
            //   var pt_pose = rdk.MultiplyMatSimple(mmm, nnn);
            AddGeometry(_fromitem, i_id, mmm);
        }
        //__________________________________________________________________________________________________________________________
        public string AddGeometry(string _fromitem, string i_id, double[,] pose)
        {
            double itemId = Convert.ToDouble(i_id);
            double fromitem = Convert.ToDouble(_fromitem);

            channel.clear_buffer();
            channel.push("CopyFaces\n");
            channel.push_with_reverse(fromitem);
            channel.push_with_reverse(itemId);
            double[] mat_send = ToDoubles(pose);
            byte[] b =channel.Get_Bytes_From_Double_Array(mat_send);
            channel.push(b);
            channel.send();
            string s = Read_status_str();
            return s;
        }
        //__________________________________________________________________________________________________________________________
        //public string setVisible(string id, bool visible, bool visible_frame)
        //{
        //    double itemId = Convert.ToDouble(id);
        //    channel.clear_buffer();
        //    channel.push("G_Visible\n");
        //    channel.push_with_reverse(itemId);
        //    channel.push_with_reverse(Convert.ToInt32(visible));
        //    channel.push_with_reverse(Convert.ToInt32(visible_frame));

        //    channel.send();
        //    string s = Read_status_str();
        //    return s;
        //}
        //__________________________________________________________________________________________________________________________


        //public void draw_Point(string _fromitem, double x,double y,double z)
        //{
        //    var mmm = transl(x, y, z);
        //    //   var nnn = rdk.rotz(Math.Atan2(my_ViX[kk], my_ViY[kk]));
        //    //   var pt_pose = rdk.MultiplyMatSimple(mmm, nnn);
        //    AddGeometry(_fromitem,mmm);
        //}

        //public string AddGeometry(string _fromitem, double[,] pose)
        //{
        //    double fromitem = Convert.ToDouble(_fromitem);

        //    channel.clear_buffer();
        //    channel.push("CopyFaces\n");
        //    channel.push_with_reverse(fromitem);
        //    double[] mat_send = ToDoubles(pose);
        //    byte[] b = channel.Get_Bytes_From_Double_Array(mat_send);
        //    channel.push(b);
        //    channel.send();
        //    string s = Read_status_str();
        //    return s;
        //}
        ////__________________________________________________________________________________________________________________________





        public string CloseRoboDK()
        {
            channel.clear_buffer();
            channel.push("QUIT\n");
            channel.send();
            string s = Read_status_str();
            return s;
        }
        //__________________________________________________________________________________________________________________________
        public string HideRoboDK()
        {
            channel.clear_buffer();
            channel.push("HIDE\n");
            channel.send();
            string s = Read_status_str();
            return s;           
        }
        //__________________________________________________________________________________________________________________________
        public List<string> Version()
        {
            List<string> ret_str = new List<string>();
            channel.clear_buffer();
            channel.push("Version\n");

            string appName = channel.read_line();
            UInt32 bitArch = channel.read_int();
            string ver4 = channel.read_line();
            string dateBuild = channel.read_line();
            string s = Read_status_str();

            ret_str.Add(appName);
            ret_str.Add(bitArch.ToString());
            ret_str.Add(ver4);
            ret_str.Add(dateBuild);

            return ret_str;
        }
        //__________________________________________________________________________________________________________________________
        public void Move_Object(string target, double[,] matTarget, string itemrobot, int movetype,bool blocking = true)
        {
            double _target = Convert.ToDouble(target);
            double _itemrobot = Convert.ToDouble(itemrobot);

            channel.clear_buffer();
           
            if (blocking){
                channel.push("MoveXb\n");
            }
            else{
                channel.push("MoveX\n");
            }
            int m = movetype;
            channel.push_with_reverse(m);

            //if (target != null)
            //{
            //    UInt32 i = 3;
            //    channel.push(3);
            //    send_array(null);
            //    channel.push(_target);
            //}
            //    else if (matTarget != null && matTarget.IsHomogeneous())
            //     {
                //UInt32 i = 2;
                //channel.push_with_reverse(i);
                //send_array(matTarget.ToDoubles());
                //double d = 0;
                //channel.push_with_reverse(d);
            //   }
            //    else
            //     {
            // throw new RdkException("Invalid target type"); //raise Exception('Problems running function');
            //     }

            channel.push_with_reverse(_itemrobot);
            string s = Read_status_str();
            //if (blocking)
            //{
            //    ////itemrobot.WaitMove();
            //    //ReceiveTimeout = 360000 * 1000;
            //    //check_status();//will wait here;
            //    //ReceiveTimeout = DefaultSocketTimeoutMilliseconds;
            //}
        }








    }// class
}// namespace


