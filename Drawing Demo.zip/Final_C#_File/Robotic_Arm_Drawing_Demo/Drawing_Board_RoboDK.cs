﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Tools
{
    class Drawing_Board_RoboDK
    {
        RoboDK_Manager rdk;

        public List<string> robot = new List<string>();
        public List<string> rbt_pen = new List<string>();
        public List<string> bfr_curve = new List<string>();
        List<double[]> point_Buffer = new List<double[]>();

        public double Robot_Board_X_length = 940.0;
        public double Robot_Board_Y_Length = 2000.0;
        public double Drawing_Board_X_length;
        public double Drawing_Board_Y_Length;

        double UnitX, UnitY, UnitZ;

        public Color pen_colour;

        //______________________________________________________________________________________________________
        public Drawing_Board_RoboDK(double rbtX, double rbtY, double drawX, double drawY)
        {
            this.Robot_Board_X_length = rbtX;
            this.Robot_Board_Y_Length = rbtY;

            Drawing_Board_X_length = drawX;
            Drawing_Board_Y_Length = drawY;

            rdk = new RoboDK_Manager();
        }
        //______________________________________________________________________________________________________
        public bool connect()
        {
            if (rdk.connected_With_RoboDK())
            {
                robot = rdk.Get_Robot_Details();
                rbt_pen = rdk.Item("Board & image", (int)RoboDK_Manager.ItemType.ITEM_TYPE_NONE);             
                return true;
            }
            else
            {
                return false;
            }
        }
        //______________________________________________________________________________________________________
        public string Go_to_Pos(string pos)
        {
           string s= rdk.Move_pos(robot[0], pos);
            return s;
        }
        //______________________________________________________________________________________________________
        public string Get_Pos()
        {
            string s = rdk.Get_Pose(robot[0]);
            return s;
        }
        //______________________________________________________________________________________________________
        public string Get_current_Position()
        {
            double[] p2 = new double[6];
           var v = point_Buffer[point_Buffer.Count - 1];

            string  s =  ((int)v[0]).ToString() + ",";
                    s += ((int)v[1]).ToString() + ",";
                    s += ((int)v[2]).ToString() + ",";
            s += "0, 0, 0";
            return s;
        }
        //______________________________________________________________________________________________________
        public void draw(int posX, int posY, int posZ)
        {
            List<double[]> pt = new List<double[]>();

            push(posX, posY, posZ);

            if (point_Buffer.Count > 1)
            {
                double[] p1 = new double[6];

                var v = point_Buffer[point_Buffer.Count - 2];

                p1[0] = v[0];
                p1[1] = v[1];
                p1[2] = v[2];
                p1[3] = 0.0;
                p1[4] = 1.0;
                p1[5] = 0.0;
                pt.Add(p1);

                double[] p2 = new double[6];
                v = point_Buffer[point_Buffer.Count - 1];
                p2[0] = v[0];
                p2[1] = v[1];
                p2[2] = v[2];
                p2[3] = 0.0;
                p2[4] = 1.0;
                p2[5] = 0.0;
                pt.Add(p2);

                var crv = rdk.AddCurve(rbt_pen[0], pt, false, (int)RoboDK_Manager.projection_types.PROJECTION_ALONG_NORMAL_RECALC);
                rdk.setColorCurve(crv[0],pen_colour);
                bfr_curve.Add(crv[0]);
            }
        }
        //_________________________________________________________________________________________________________
        public void set_colour(Color c)
        {
            pen_colour = c;
            //rdk.setColorCurve(rbt_pen[0],c);
        }
        //_________________________________________________________________________________________________________
        public void clear_point_buffer()
        {
            point_Buffer.Clear();
        }
        //_________________________________________________________________________________________________________
        public void push(int x, int y,int z)
        {
            double[] p = new double[3];
            p[0] = Get_Cal_X(x);
            p[1] = Get_Cal_Y(y);
            p[2] = 0.0;
            point_Buffer.Add(p);
        }
        //_________________________________________________________________________________________________________
        public double Get_Cal_X(int x)
        {
            UnitX = Robot_Board_X_length / Drawing_Board_X_length;
            double d = Robot_Board_X_length - (UnitX * x);
            return d;
        }
        //_________________________________________________________________________________________________________
        public double Get_Cal_Y(int y)
        {
            UnitY = Robot_Board_Y_Length / Drawing_Board_Y_Length;
            double d = Robot_Board_Y_Length - (UnitY * y);
            return d;
        }
        //_________________________________________________________________________________________________________
        public string Get_Cal_PosX(int x)
        {
           UnitX = Robot_Board_X_length / Drawing_Board_X_length;
           double d = Robot_Board_X_length-(UnitX * x);
           return d.ToString();
        }
        //_________________________________________________________________________________________________________
        public string Get_Cal_PosY(int y)
        {
            UnitY = Robot_Board_Y_Length / Drawing_Board_Y_Length;
            double d = Robot_Board_Y_Length-(UnitY * y);
            return d.ToString();
        }
        //_________________________________________________________________________________________________________
        public void Clear()
        {
            if (bfr_curve.Count <= 0) return;
            foreach (string s in bfr_curve)
            {
               rdk.Delete(s);
            }
        }
        //_________________________________________________________________________________________________________
 
       



        //List<double[]> t = new List<double[]>();



        //double[] A = new double[] { 0.17770898, 0.72315927, 0.66742804 };
        //double[] B = new double[] { -0.65327074, -0.4196453, 0.63018661 };
        //double[] C = new double[] { 0.65382635, 0.42081934, -0.62882604 };
        //double[] D = new double[] { -0.17907021, -0.72084723, -0.66956189 };
        //double[] E = new double[] { -0.73452809, 0.5495376, -0.39809158 };
        //double[] F = new double[] { 0.73451554, -0.55094017, 0.39617148 };

        //t.Add(E); t.Add(B); t.Add(A);
        //t.Add(E); t.Add(D); t.Add(B);
        //t.Add(E); t.Add(C); t.Add(D);
        //t.Add(E); t.Add(A); t.Add(C);
        //t.Add(F); t.Add(A); t.Add(B);
        //t.Add(F); t.Add(B); t.Add(D);
        //t.Add(F); t.Add(D); t.Add(C);
        //t.Add(F); t.Add(C); t.Add(A);

        //double[][] SHAPE = {
        //    E, B, A,
        //    E, D, B,
        //    E, C, D,
        //    E, A, C,
        //    F, A, B,
        //    F, B, D,
        //    F, D, C,
        //    F, C, A
        //};



        //   var v = rdk.AddShape(t, 0, true);
        //  rdk.Scale(v[0], 500.0);
        //         rdk.Recolor(v[0]);
        // rdk.setColorCurve(v[0]);

        //List<double[]> pt = new List<double[]>();

        //double[] p = new double[] { 940, 0.0, 0, 0.0, 1.0, 0.0 }; pt.Add(p);
        //             p = new double[] {940.0,2000.0, 0.0,0.0,1.0,0.0}; pt.Add(p);



        //    p = new double[] { 0, 0, 0, 1, 1, 1 }; pt.Add(p);
        //p = new double[] { 0, 200, -1, 0, 1, 0 }; pt.Add(p);
        //p = new double[] { 0, 200, -2, 0, 1, 0 }; pt.Add(p);


        //p1[0] = 0; p1[1] = 200; p1[2] = 2; p1[3] = 0; p1[4] = 1; p1[5] = 0;
        //double[] p2 = new double[6];
        //p2[0] = 0; p2[1] = 200; p2[2] = 1; p2[3] = 0; p2[4] = 1; p2[5] = 0; pt.Add(p2);
        //double[] p3 = new double[6];
        //p3[0] = 0; p3[1] = 200; p3[2] = 0; p3[3] = 0; p3[4] = 1; p3[5] = 0; pt.Add(p3);
        //double[] p4 = new double[6];
        //p4[0] = 0; p4[1] = 200; p4[2] = -6; p4[3] = 0; p4[4] = 1; p4[5] = 0; pt.Add(p4);
        //double[] p5 = new double[6];
        //p5[0] = 0; p5[1] = 200; p5[2] = -3; p5[3] = 0; p5[4] = 1; p5[5] = 0; pt.Add(p5);


        //var crv = rdk.Item("bb", (int)RoboDK_Manager.ItemType.ITEM_TYPE_NONE);
        // var obj = rdk.ItemUserPick("Select object to project the path<br>(select cancel if you do not want to project the path)",(int) RoboDK_Manager.ItemType.ITEM_TYPE_OBJECT);



        //        var crv = rdk.AddCurve(rbt_pen[0], pt, false, (int)RoboDK_Manager.projection_types.PROJECTION_ALONG_NORMAL_RECALC);
        //rdk.setColorCurve(crv[0]);
        // rdk.setName(crv[0], "bb");
        //      rdk.Scale(crv[0], 10, 10, 10);

        //rdk.Recolor(crv[0]);
        // rdk.setValue(crv[0], "DISPLAY", "LINEW=20");
        // rdk.setValue(crv[0], "Display", "LINEW=20");
        //  rdk.Delete(crv[0]);


        ///////////////////////////////////////////////////////////////////////
        //var partref = rdk.Item("Part 1", (int)RoboDK_Manager.ItemType.ITEM_TYPE_NONE);
        ////   var partref = rdk.Item("Board & image", (int)RoboDK_Manager.ItemType.ITEM_TYPE_NONE);

        //rdk.Copy(Convert.ToDouble(partref[0]), 0);
        //rdk.Paste(partref[0]);
        //rdk.setName(partref[0], "writting Board");

        //partref = rdk.Item("writting Board", (int)RoboDK_Manager.ItemType.ITEM_TYPE_NONE);

        //var mat = rdk.transl(200, 0, 600);
        //rdk.setPos(mat, partref[0]);
        //rdk.setVisible(partref[0], true, false);


        //string s = "";

















        // rdk.setPose(transl(225, 100, 75)) #set item position with respect to parent
        // partref.setVisible(True, False)

        //    var robot = rdk.ItemUserPick("", (int)RoboDK_Manager.ItemType.ITEM_TYPE_ROBOT);
        //    var framedraw = rdk.Item("Frame draw",(int)RoboDK_Manager.ItemType.ITEM_TYPE_NONE);
        //    var tooldraw = rdk.Item("Tool", (int)RoboDK_Manager.ItemType.ITEM_TYPE_NONE);
        //    var pixel_ref = rdk.Item("pixel", (int)RoboDK_Manager.ItemType.ITEM_TYPE_NONE);
        //    var board_1m = rdk.Item("Blackboard 250mm", (int)RoboDK_Manager.ItemType.ITEM_TYPE_NONE);

        //    var tr = rdk.transl(0, 0, 0);

        //    double[] xyzwpr =rdk.String_2_Values(txt_get_pos.Text);
        //    double[,] mat = rdk.FromTxyzRxyz(xyzwpr[0], xyzwpr[1], xyzwpr[2], xyzwpr[3], xyzwpr[4], xyzwpr[5]);

        //    rdk._moveX(mat, pixel_ref[0], 1, true); 
        //    System.Threading.Thread.Sleep(1000);
        //    return;
        //  var image = rdk.Item("Board & image", (int)RoboDK_Manager.ItemType.ITEM_TYPE_NONE);
        //rdk.Type(Convert.ToDouble(s[0]));
        //string msg= rdk.Delete(Convert.ToDouble(123456));
        //  rdk.Copy(Convert.ToDouble(framedraw[0]),1);
        // var board_draw = rdk.Paste(framedraw[0]);
        ///////////////////////////////////////////
        //var home_joints = rdk.JointsHome(Convert.ToDouble(robot[0]));
        //var p2 = rdk.SolveFK(robot[0], home_joints); 



        // var p = rdk.Pose(board_1m[0]);


        //var p3 = rdk.Pose(tooldraw[0]);
        ////////////////////////////////////////////

        //double[] arrX = { 809, 746, 843, 642, 624, 603 };
        //double[] arrY = { 989, 1155, 1769, 1860, 1616, 1559 };
        //double[] my_PiX = { 800, 736, 843, 636, 624 };
        //double[] my_PiY = { 986, 1152, 1758, 1851, 1604 };
        //double[] my_ViX = { -0.9, -0.99, -0.46, -0.53, -0.27 };
        //double[] my_ViY = { -0.36, -0.116, -0.88, -0.84, -0.96 };
        //int kk = 1;

        //double[,] orient_frame2tool = new double[4, 4];

        //orient_frame2tool[0, 0] = -0.9999999999999951; orient_frame2tool[0, 1] = 8.742278191441028e-08; orient_frame2tool[0, 2] = 4.371139006309471e-08; orient_frame2tool[0, 3] = 0;
        //orient_frame2tool[1, 0] =8.742277809303876e-08; orient_frame2tool[1, 1] = 0.9999999999999922; orient_frame2tool[1, 2] =-8.742278000372469e-08; orient_frame2tool[1, 3] =0;
        //orient_frame2tool[2, 0] =-4.3711397705837e-08; orient_frame2tool[2, 1] = -8.742277618235311e-08; orient_frame2tool[2, 2] =-0.9999999999999951; orient_frame2tool[2, 3] =0;
        //orient_frame2tool[3, 0] =0.0; orient_frame2tool[3, 1] =0.0; orient_frame2tool[3, 2] =0.0; orient_frame2tool[3, 3] =1.0;



        //while (kk<5)
        //{
        //    var tr = rdk.transl(arrX[kk], arrY[kk], 0);
        //    var target0 = rdk.MultiplyMatSimple(tr, orient_frame2tool);
        //    var trnsl = rdk.transl(0, 0, -10);
        //    var target0_app = rdk.MultiplyMatSimple(target0, trnsl);
        //    int move_type = 2;
        //    rdk._moveX(target0_app, board_1m[0], move_type, true);
        //    //////////////////////////////////////////////////////
        //    //var mmm = rdk.transl(my_PiX[kk], my_PiY[kk], 0);
        //    //var nnn = rdk.rotz(Math.Atan2(my_ViX[kk], my_ViY[kk]));
        //    //var pt_pose = rdk.MultiplyMatSimple(mmm, nnn);
        //    //rdk.AddGeometry(pixel_ref[0], board_1m[0], pt_pose);

        //    kk = kk + 1;

        //    System.Threading.Thread.Sleep(100);

        //}


















        //    //var robot = rdk.ItemUserPick("", (int)RoboDK_Manager.ItemType.ITEM_TYPE_ROBOT);

        //    //var tooldraw = rdk.Item("Tool", (int)RoboDK_Manager.ItemType.ITEM_TYPE_NONE);

        //    var framedraw = rdk.Item("Frame draw", (int)RoboDK_Manager.ItemType.ITEM_TYPE_NONE);
        //    var pixel_ref = rdk.Item("pixel", (int)RoboDK_Manager.ItemType.ITEM_TYPE_NONE);

        //    //// rdk.Scale(pixel_ref[0], 2, 2, 1);

        //    // var image = rdk.Item("Board & image", (int)RoboDK_Manager.ItemType.ITEM_TYPE_NONE);
        //    // rdk.Delete(image[0]);


        //    // var board_1m = rdk.Item("Blackboard 250mm", (int)RoboDK_Manager.ItemType.ITEM_TYPE_NONE);
        //    // rdk.Copy(board_1m[0], 1);
        //    // var board_draw = rdk.Paste(framedraw[0]);

        //    var brd = rdk.Item("Board & image", (int)RoboDK_Manager.ItemType.ITEM_TYPE_NONE);
        ////    rdk.setVisible(brd[0], true,false);           
        //   // rdk.setName(brd[0], "Board & image");
        //    rdk.Scale(brd[0], 3, 8, 1);

        //   // board_1m = rdk.Item("Blackboard 250mm", (int)RoboDK_Manager.ItemType.ITEM_TYPE_NONE);



        //    //var tr = rdk.transl(0, 0, 0);

        //    //double[] xyzwpr =rdk.String_2_Values(txt_get_pos.Text);
        //    //double[,] mat = rdk.FromTxyzRxyz(xyzwpr[0], xyzwpr[1], xyzwpr[2], xyzwpr[3], xyzwpr[4], xyzwpr[5]);

        //    //rdk._moveX(mat, pixel_ref[0], 1, true); 
        //    //System.Threading.Thread.Sleep(1000);
        //    //return;
        //    //  var image = rdk.Item("Board & image", (int)RoboDK_Manager.ItemType.ITEM_TYPE_NONE);
        //    //rdk.Type(Convert.ToDouble(s[0]));
        //    //string msg= rdk.Delete(Convert.ToDouble(123456));
        //    //  rdk.Copy(Convert.ToDouble(framedraw[0]),1);
        //    // var board_draw = rdk.Paste(framedraw[0]);
        //    ///////////////////////////////////////////
        //    //var home_joints = rdk.JointsHome(Convert.ToDouble(robot[0]));
        //    //var p2 = rdk.SolveFK(robot[0], home_joints); 



        //    // var p = rdk.Pose(board_1m[0]);


        //    //var p3 = rdk.Pose(tooldraw[0]);
        //    ////////////////////////////////////////////

        //    //double[] arrX = { 809, 746, 843, 642, 624, 603 };
        //    //double[] arrY = { 989, 1155, 1769, 1860, 1616, 1559 };


        //    //double[] my_PiX = { 0, 10,20,30,40,50,100 };
        //    //double[] my_PiY = { 100, 100,100,100,100,100,100};

        //    int kk = 1;

        //    //double[,] orient_frame2tool = new double[4, 4];

        //    //orient_frame2tool[0, 0] = -0.9999999999999951; orient_frame2tool[0, 1] = 8.742278191441028e-08; orient_frame2tool[0, 2] = 4.371139006309471e-08; orient_frame2tool[0, 3] = 0;
        //    //orient_frame2tool[1, 0] =8.742277809303876e-08; orient_frame2tool[1, 1] = 0.9999999999999922; orient_frame2tool[1, 2] =-8.742278000372469e-08; orient_frame2tool[1, 3] =0;
        //    //orient_frame2tool[2, 0] =-4.3711397705837e-08; orient_frame2tool[2, 1] = -8.742277618235311e-08; orient_frame2tool[2, 2] =-0.9999999999999951; orient_frame2tool[2, 3] =0;
        //    //orient_frame2tool[3, 0] =0.0; orient_frame2tool[3, 1] =0.0; orient_frame2tool[3, 2] =0.0; orient_frame2tool[3, 3] =1.0;



        //    //    while (kk < 5)
        //    //   {
        //    //var tr = rdk.transl(arrX[kk], arrY[kk], 0);
        //    //var target0 = rdk.MultiplyMatSimple(tr, orient_frame2tool);
        //    //var trnsl = rdk.transl(0, 0, -10);
        //    //var target0_app = rdk.MultiplyMatSimple(target0, trnsl);
        //    //int move_type = 2;
        //    //rdk._moveX(target0_app, board_1m[0], move_type, true);
        //    //////////////////////////////////////////////////////

        //    //rdk.draw_Point(pixel_ref[0], 0, 100, 0);
        //    //rdk.draw_Point(pixel_ref[0], 11, 100, 0);
        //    //rdk.draw_Point(pixel_ref[0], 22, 100, 0);
        //    //rdk.draw_Point(pixel_ref[0], 33, 100, 0);

        //    rdk.Recolor(pixel_ref[0]);

        //    rdk.draw_Point(pixel_ref[0], brd[0], 0, 100, 0);
        //    rdk.draw_Point(pixel_ref[0], brd[0], 11, 100, 0);
        //    rdk.draw_Point(pixel_ref[0], brd[0], 22, 100, 0);
        //    rdk.draw_Point(pixel_ref[0], brd[0], 33, 100, 0);

        //    // var mmm = rdk.transl(, , 0);
        //    //   var nnn = rdk.rotz(Math.Atan2(my_ViX[kk], my_ViY[kk]));
        //    //   var pt_pose = rdk.MultiplyMatSimple(mmm, nnn);
        //    //   rdk.AddGeometry(pixel_ref[0], board_1m[0], mmm);

        //    kk = kk + 1;

        //        System.Threading.Thread.Sleep(100);

        // //   }




















    }// class
}// namespace






