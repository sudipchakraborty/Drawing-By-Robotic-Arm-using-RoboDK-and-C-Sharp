﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
//using OpenCvSharp;
using System.Runtime.CompilerServices;
using System.Security.Policy;
using Tools;
using System.Security.Permissions;
using System.Drawing;
using System.Timers;

using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tools
{
   public static class utilUI
    {
        public static void h_slider_Config(HScrollBar hs, int min, int max, int interval)
        {
            hs.Minimum = min;
            hs.Maximum = max;
            hs.SmallChange = interval;
        }
        //____________________________________________________________________________________
        public static int[] Get_ARGB_From_Colour_Picker()
        {
            int[] argb = new int[4];

            ColorDialog colorDlg = new ColorDialog();
            if (colorDlg.ShowDialog() == DialogResult.OK)
            {
                Color s = colorDlg.Color;
                argb[0] = s.A;
                argb[1] = s.R;
                argb[2] = s.G;
                argb[3] = s.B;
            }
            else
            {
                argb[0] = 0;
                argb[1] = 0;
                argb[2] = 0;
                argb[3] = 0;
            }
            return argb;
        }
        //____________________________________________________________________________________
        public static Color Get_Colour_From_Colour_Picker()
        {
            Color c;

            ColorDialog colorDlg = new ColorDialog();
            if (colorDlg.ShowDialog() == DialogResult.OK)
            {
                c = colorDlg.Color;
                
            }
            else
            {
                c = Color.Transparent;
            }
            return c;
        }
        //____________________________________________________________________________________
        public static int[] Get_ARGB_from_Colour(Color s)
        {
            int[] argb = new int[4];
            argb[0] = s.A;
            argb[1] = s.R;
            argb[2] = s.G;
            argb[3] = s.B;
            return argb;
        }
        //____________________________________________________________________________________






































    }// class
}// namespace
