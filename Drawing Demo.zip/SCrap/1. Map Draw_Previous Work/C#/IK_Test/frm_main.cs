﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Tools;
using RoboDk;

namespace IK_Test
{
    public partial class frm_main : Form
    {
        RoboDK_Manager rdk = new RoboDK_Manager();

        const int ITEM_TYPE_ROBOT = 2;

        public frm_main()
        {
            InitializeComponent();
        }
        //___________________________________________________________________________________________________
        private void Form1_Load(object sender, EventArgs e)
        {
            dg_param.Rows.Add(12);
            dg_param[0, 0].Value = "J1";
            dg_param[0, 1].Value = "J2";
            dg_param[0, 2].Value = "J3";
            dg_param[0, 3].Value = "J4";
            dg_param[0, 4].Value = "J5";
            dg_param[0, 5].Value = "J6";

            dg_param[0, 6].Value = "TX";
            dg_param[0, 7].Value = "TY";
            dg_param[0, 8].Value = "TZ";
            dg_param[0, 9].Value = "RX";
            dg_param[0, 10].Value= "RY";
            dg_param[0, 11].Value= "RZ";


            dg_param[1, 0].Value = "-165"; dg_param[2, 0].Value = "165";
            dg_param[1, 1].Value = "-110"; dg_param[2, 1].Value = "110";
            dg_param[1, 2].Value = "-90"; dg_param[2, 2].Value = "70";
            dg_param[1, 3].Value = "-100"; dg_param[2, 3].Value = "160";
            dg_param[1, 4].Value = "-120"; dg_param[2, 4].Value = "120";
            dg_param[1, 5].Value = "-400"; dg_param[2, 5].Value = "400";

            dg_param[1, 6].Value = "-100"; dg_param[2, 6].Value = "100";
            dg_param[1, 7].Value = "-100"; dg_param[2, 7].Value = "100";
            dg_param[1, 8].Value = "-100"; dg_param[2, 8].Value = "100";
            dg_param[1, 9].Value = "-100"; dg_param[2, 9].Value = "100";
            dg_param[1, 10].Value = "-100"; dg_param[2, 10].Value = "100";
            dg_param[1, 11].Value = "-100"; dg_param[2, 11].Value = "100";

            int J1_min = Convert.ToInt32(dg_param[1, 0].Value.ToString()); 
            int J1_max = Convert.ToInt32(dg_param[2, 0].Value.ToString());
            int J2_min = Convert.ToInt32(dg_param[1, 1].Value.ToString()); 
            int J2_max = Convert.ToInt32(dg_param[2, 1].Value.ToString());
            int J3_min = Convert.ToInt32(dg_param[1, 2].Value.ToString()); 
            int J3_max = Convert.ToInt32(dg_param[2, 2].Value.ToString());
            int J4_min = Convert.ToInt32(dg_param[1, 3].Value.ToString()); 
            int J4_max = Convert.ToInt32(dg_param[2, 3].Value.ToString());
            int J5_min = Convert.ToInt32(dg_param[1, 4].Value.ToString()); 
            int J5_max = Convert.ToInt32(dg_param[2, 4].Value.ToString());
            int J6_min = Convert.ToInt32(dg_param[1, 5].Value.ToString()); 
            int J6_max = Convert.ToInt32(dg_param[2, 5].Value.ToString());
            int tx_min = Convert.ToInt32(dg_param[1, 6].Value.ToString()); 
            int tx_max = Convert.ToInt32(dg_param[2, 6].Value.ToString());
            int ty_min = Convert.ToInt32(dg_param[1, 7].Value.ToString()); 
            int ty_max = Convert.ToInt32(dg_param[2, 7].Value.ToString());
            int tz_min = Convert.ToInt32(dg_param[1, 8].Value.ToString()); 
            int tz_max = Convert.ToInt32(dg_param[2, 8].Value.ToString());
            int rx_min = Convert.ToInt32(dg_param[1, 9].Value.ToString()); 
            int rx_max = Convert.ToInt32(dg_param[2, 9].Value.ToString());
            int ry_min = Convert.ToInt32(dg_param[1, 10].Value.ToString()); 
            int ry_max = Convert.ToInt32(dg_param[2, 10].Value.ToString());
            int rz_min = Convert.ToInt32(dg_param[1, 11].Value.ToString()); 
            int rz_max = Convert.ToInt32(dg_param[2, 11].Value.ToString());

            utilUI.h_slider_Config(hscroll_J1, J1_min, J1_max, 1);
            utilUI.h_slider_Config(hscroll_J2, J2_min, J2_max, 1);
            utilUI.h_slider_Config(hscroll_J3, J3_min, J3_max, 1);
            utilUI.h_slider_Config(hscroll_J4, J4_min, J4_max, 1);
            utilUI.h_slider_Config(hscroll_J5, J5_min, J5_max, 1);
            utilUI.h_slider_Config(hscroll_J6, J6_min, J6_max, 1);

            utilUI.h_slider_Config(hScroll_TX, tx_min, tx_max, 1);
            utilUI.h_slider_Config(hScroll_TY, ty_min, ty_max, 1);
            utilUI.h_slider_Config(hScroll_TZ, tz_min, tz_max, 1);
            utilUI.h_slider_Config(hScroll_RX, rx_min, rx_max, 1);
            utilUI.h_slider_Config(hScroll_RY, ry_min, ry_max, 1);
            utilUI.h_slider_Config(hScroll_RZ, rz_min, rz_max, 1);


            if (rdk.connected_With_RoboDK())
            {
               // btn_connect.BackColor = Color.Green;

                txt_robot_name.Text = rdk.Robot_Name;
                txt_item_id.Text = rdk.itemId.ToString();
                txt_type.Text = rdk.robot_type.ToString();
                txt_API.Text = rdk.api.ToString();
                txt_API_Version.Text = rdk.api_version.ToString();
                txt_build.Text = rdk.build.ToString();
            }
            else
            {
               // btn_connect.BackColor = Color.Red;
            }



        }
        //___________________________________________________________________________________________________
        private void btn_start_Click(object sender, EventArgs e)
        {     
           timer1.Enabled = true;
        }
        //___________________________________________________________________________________________________
        private void btn_position_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            timer1.Interval = 1;
        }
        //___________________________________________________________________________________________________
        private void timer1_Tick(object sender, EventArgs e)
        {
            txt_msg.Text = rdk.LastStatusMessage;
        }
        //___________________________________________________________________________________________________     
        private void hscroll_J1_Scroll(object sender, ScrollEventArgs e)
        {
            txt_j1.Text = (hscroll_J1.Value).ToString();
            txt_set_joints.Text=rdk.update_Single_Joint(txt_set_joints.Text, 0, txt_j1.Text);
        }
        //___________________________________________________________________________________________________     
        private void hscroll_J2_Scroll(object sender, ScrollEventArgs e)
        {
            txt_j2.Text = (hscroll_J2.Value).ToString();
            txt_set_joints.Text = rdk.update_Single_Joint(txt_set_joints.Text, 1, txt_j2.Text);
        }
        //___________________________________________________________________________________________________     
        private void hscroll_J3_Scroll(object sender, ScrollEventArgs e)
        {
            txt_j3.Text = (hscroll_J3.Value).ToString();
            txt_set_joints.Text = rdk.update_Single_Joint(txt_set_joints.Text, 2, txt_j3.Text);
        }
        //___________________________________________________________________________________________________     
        private void hscroll_J4_Scroll(object sender, ScrollEventArgs e)
        {
            txt_j4.Text = (hscroll_J4.Value).ToString();
            txt_set_joints.Text = rdk.update_Single_Joint(txt_set_joints.Text, 3, txt_j4.Text);
        }
        //___________________________________________________________________________________________________     
        private void hscroll_J5_Scroll(object sender, ScrollEventArgs e)
        {
            txt_j5.Text = (hscroll_J5.Value / 10.0).ToString();
            txt_set_joints.Text = rdk.update_Single_Joint(txt_set_joints.Text, 4, txt_j5.Text);
        }
        //___________________________________________________________________________________________________     
         private void hscroll_J6_Scroll(object sender, ScrollEventArgs e)
        {
            txt_j6.Text = (hscroll_J6.Value).ToString();
            txt_set_joints.Text = rdk.update_Single_Joint(txt_set_joints.Text, 5, txt_j6.Text);
        }
        //___________________________________________________________________________________________________
        private void hScroll_TX_Scroll(object sender, ScrollEventArgs e)
        {
            txt_tx.Text = (hScroll_TX.Value).ToString();
            txt_set_pos.Text = rdk.update_Single_pos(txt_set_pos.Text, 0, txt_tx.Text);
        }
        //___________________________________________________________________________________________________
        private void hScroll_TY_Scroll(object sender, ScrollEventArgs e)
        {
            txt_ty.Text = (hScroll_TY.Value).ToString();
            txt_set_pos.Text = rdk.update_Single_pos(txt_set_pos.Text, 1, txt_ty.Text);
        }
        //___________________________________________________________________________________________________
        private void hScroll_TZ_Scroll(object sender, ScrollEventArgs e)
        {
            txt_tz.Text = (hScroll_TZ.Value).ToString();
            txt_set_pos.Text = rdk.update_Single_pos(txt_set_pos.Text, 2, txt_tz.Text);
        }
        //___________________________________________________________________________________________________
        private void hScroll_RX_Scroll(object sender, ScrollEventArgs e)
        {
            txt_rx.Text = (hScroll_RX.Value).ToString();
            txt_set_pos.Text = rdk.update_Single_pos(txt_set_pos.Text, 3, txt_rx.Text);
        }
        //___________________________________________________________________________________________________
        private void hScroll_RY_Scroll(object sender, ScrollEventArgs e)
        {
            txt_rx.Text = (hScroll_RX.Value).ToString();
            txt_set_pos.Text = rdk.update_Single_pos(txt_set_pos.Text, 4, txt_rx.Text);
        }
        //___________________________________________________________________________________________________
        private void hScroll_RZ_Scroll(object sender, ScrollEventArgs e)
        {
            txt_rz.Text = (hScroll_RZ.Value).ToString();
            txt_set_pos.Text = rdk.update_Single_pos(txt_set_pos.Text, 5, txt_rz.Text);
        }
        //___________________________________________________________________________________________________
        private void btn_get_Position_Click(object sender, EventArgs e)
        {
            txt_Get_Joints.Text = rdk.read_joints2();
        }
        //___________________________________________________________________________________________________
        private void btn_set_joints_Click(object sender, EventArgs e)
        {
            rdk.Move_Joints(txt_set_joints.Text.ToString());
        }
        //___________________________________________________________________________________________________
        private void btn_set_pos_Click(object sender, EventArgs e)
        {
            rdk.Move_pos(txt_set_pos.Text.ToString());
        }
        //___________________________________________________________________________________________________
        private void btn_get_pos_Click(object sender, EventArgs e)
        {
            txt_get_pos.Text = rdk.read_Pose();
        }

        private void btn_draw_Click(object sender, EventArgs e)
        {
            var robot = rdk.ItemUserPick("", (int)RoboDK_Manager.ItemType.ITEM_TYPE_ROBOT);
            var framedraw = rdk.Item("Frame draw",(int)RoboDK_Manager.ItemType.ITEM_TYPE_NONE);
            var tooldraw = rdk.Item("Tool", (int)RoboDK_Manager.ItemType.ITEM_TYPE_NONE);
            var pixel_ref = rdk.Item("pixel", (int)RoboDK_Manager.ItemType.ITEM_TYPE_NONE);
            var board_1m = rdk.Item("Blackboard 250mm", (int)RoboDK_Manager.ItemType.ITEM_TYPE_NONE);

            //var tr = rdk.transl(0, 0, 0);

            //double[] xyzwpr =rdk.String_2_Values(txt_get_pos.Text);
            //double[,] mat = rdk.FromTxyzRxyz(xyzwpr[0], xyzwpr[1], xyzwpr[2], xyzwpr[3], xyzwpr[4], xyzwpr[5]);

            //rdk._moveX(mat, pixel_ref[0], 1, true); 
            //System.Threading.Thread.Sleep(1000);
            //return;
            //  var image = rdk.Item("Board & image", (int)RoboDK_Manager.ItemType.ITEM_TYPE_NONE);
            //rdk.Type(Convert.ToDouble(s[0]));
            //string msg= rdk.Delete(Convert.ToDouble(123456));
            //  rdk.Copy(Convert.ToDouble(framedraw[0]),1);
            // var board_draw = rdk.Paste(framedraw[0]);
            ///////////////////////////////////////////
            //var home_joints = rdk.JointsHome(Convert.ToDouble(robot[0]));
            //var p2 = rdk.SolveFK(robot[0], home_joints); 



            // var p = rdk.Pose(board_1m[0]);


            //var p3 = rdk.Pose(tooldraw[0]);
            ////////////////////////////////////////////

            double[] arrX = { 809, 746, 843, 642, 624, 603 };
            double[] arrY = { 989, 1155, 1769, 1860, 1616, 1559 };
            double[] my_PiX = { 800, 736, 843, 636, 624 };
            double[] my_PiY = { 986, 1152, 1758, 1851, 1604 };
            double[] my_ViX = { -0.9, -0.99, -0.46, -0.53, -0.27 };
            double[] my_ViY = { -0.36, -0.116, -0.88, -0.84, -0.96 };
            int kk = 1;

            //double[,] orient_frame2tool = new double[4, 4];

            //orient_frame2tool[0, 0] = -0.9999999999999951; orient_frame2tool[0, 1] = 8.742278191441028e-08; orient_frame2tool[0, 2] = 4.371139006309471e-08; orient_frame2tool[0, 3] = 0;
            //orient_frame2tool[1, 0] =8.742277809303876e-08; orient_frame2tool[1, 1] = 0.9999999999999922; orient_frame2tool[1, 2] =-8.742278000372469e-08; orient_frame2tool[1, 3] =0;
            //orient_frame2tool[2, 0] =-4.3711397705837e-08; orient_frame2tool[2, 1] = -8.742277618235311e-08; orient_frame2tool[2, 2] =-0.9999999999999951; orient_frame2tool[2, 3] =0;
            //orient_frame2tool[3, 0] =0.0; orient_frame2tool[3, 1] =0.0; orient_frame2tool[3, 2] =0.0; orient_frame2tool[3, 3] =1.0;



            while (kk < 5)
            {
                //var tr = rdk.transl(arrX[kk], arrY[kk], 0);
                //var target0 = rdk.MultiplyMatSimple(tr, orient_frame2tool);
                //var trnsl = rdk.transl(0, 0, -10);
                //var target0_app = rdk.MultiplyMatSimple(target0, trnsl);
                //int move_type = 2;
                //rdk._moveX(target0_app, board_1m[0], move_type, true);
                //////////////////////////////////////////////////////
                var mmm = rdk.transl(my_PiX[kk], my_PiY[kk], 0);
                var nnn = rdk.rotz(Math.Atan2(my_ViX[kk], my_ViY[kk]));
                var pt_pose = rdk.MultiplyMatSimple(mmm, nnn);
                rdk.AddGeometry(pixel_ref[0], board_1m[0], pt_pose);

                kk = kk + 1;

                System.Threading.Thread.Sleep(100);

            }





        }
        //___________________________________________________________________________________________________




    }// class
}// ns