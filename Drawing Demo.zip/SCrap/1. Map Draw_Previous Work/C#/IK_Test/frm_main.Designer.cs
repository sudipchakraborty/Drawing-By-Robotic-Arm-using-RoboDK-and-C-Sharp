﻿
namespace IK_Test
{
    partial class frm_main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.txt_msg = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txt_j6 = new System.Windows.Forms.TextBox();
            this.txt_j5 = new System.Windows.Forms.TextBox();
            this.txt_j4 = new System.Windows.Forms.TextBox();
            this.txt_j3 = new System.Windows.Forms.TextBox();
            this.txt_j2 = new System.Windows.Forms.TextBox();
            this.txt_j1 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.hscroll_J6 = new System.Windows.Forms.HScrollBar();
            this.hscroll_J5 = new System.Windows.Forms.HScrollBar();
            this.hscroll_J4 = new System.Windows.Forms.HScrollBar();
            this.hscroll_J3 = new System.Windows.Forms.HScrollBar();
            this.hscroll_J2 = new System.Windows.Forms.HScrollBar();
            this.hscroll_J1 = new System.Windows.Forms.HScrollBar();
            this.hScroll_RX = new System.Windows.Forms.HScrollBar();
            this.hScroll_TZ = new System.Windows.Forms.HScrollBar();
            this.hScroll_RY = new System.Windows.Forms.HScrollBar();
            this.hScroll_RZ = new System.Windows.Forms.HScrollBar();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_tx = new System.Windows.Forms.TextBox();
            this.txt_rx = new System.Windows.Forms.TextBox();
            this.txt_ty = new System.Windows.Forms.TextBox();
            this.txt_ry = new System.Windows.Forms.TextBox();
            this.txt_tz = new System.Windows.Forms.TextBox();
            this.txt_rz = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.hScroll_TY = new System.Windows.Forms.HScrollBar();
            this.hScroll_TX = new System.Windows.Forms.HScrollBar();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_build = new System.Windows.Forms.TextBox();
            this.txt_API_Version = new System.Windows.Forms.TextBox();
            this.txt_API = new System.Windows.Forms.TextBox();
            this.txt_type = new System.Windows.Forms.TextBox();
            this.txt_item_id = new System.Windows.Forms.TextBox();
            this.txt_robot_name = new System.Windows.Forms.TextBox();
            this.btn_get_Position = new System.Windows.Forms.Button();
            this.txt_Get_Joints = new System.Windows.Forms.TextBox();
            this.txt_set_joints = new System.Windows.Forms.TextBox();
            this.btn_set_joints = new System.Windows.Forms.Button();
            this.txt_get_pos = new System.Windows.Forms.TextBox();
            this.txt_set_pos = new System.Windows.Forms.TextBox();
            this.btn_get_pos = new System.Windows.Forms.Button();
            this.btn_set_pos = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dg_param = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_draw = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg_param)).BeginInit();
            this.SuspendLayout();
            // 
            // txt_msg
            // 
            this.txt_msg.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_msg.Location = new System.Drawing.Point(11, 473);
            this.txt_msg.Margin = new System.Windows.Forms.Padding(2);
            this.txt_msg.Name = "txt_msg";
            this.txt_msg.Size = new System.Drawing.Size(930, 26);
            this.txt_msg.TabIndex = 2;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::IK_Test.Properties.Resources.srivas_university;
            this.pictureBox1.Location = new System.Drawing.Point(1226, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(98, 29);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Tempus Sans ITC", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Yellow;
            this.label13.Location = new System.Drawing.Point(164, 3);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(966, 42);
            this.label13.TabIndex = 11;
            this.label13.Text = "Forward and Inverse Kinematics Demonstration using RoboDK and C#";
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox4.Controls.Add(this.txt_j6);
            this.groupBox4.Controls.Add(this.txt_j5);
            this.groupBox4.Controls.Add(this.txt_j4);
            this.groupBox4.Controls.Add(this.txt_j3);
            this.groupBox4.Controls.Add(this.txt_j2);
            this.groupBox4.Controls.Add(this.txt_j1);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Controls.Add(this.hscroll_J6);
            this.groupBox4.Controls.Add(this.hscroll_J5);
            this.groupBox4.Controls.Add(this.hscroll_J4);
            this.groupBox4.Controls.Add(this.hscroll_J3);
            this.groupBox4.Controls.Add(this.hscroll_J2);
            this.groupBox4.Controls.Add(this.hscroll_J1);
            this.groupBox4.ForeColor = System.Drawing.Color.White;
            this.groupBox4.Location = new System.Drawing.Point(12, 211);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox4.Size = new System.Drawing.Size(470, 258);
            this.groupBox4.TabIndex = 13;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Joint Angle Input";
            // 
            // txt_j6
            // 
            this.txt_j6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_j6.Location = new System.Drawing.Point(394, 220);
            this.txt_j6.Margin = new System.Windows.Forms.Padding(2);
            this.txt_j6.Name = "txt_j6";
            this.txt_j6.Size = new System.Drawing.Size(67, 23);
            this.txt_j6.TabIndex = 2;
            this.txt_j6.Text = "0";
            this.txt_j6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_j5
            // 
            this.txt_j5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_j5.Location = new System.Drawing.Point(394, 182);
            this.txt_j5.Margin = new System.Windows.Forms.Padding(2);
            this.txt_j5.Name = "txt_j5";
            this.txt_j5.Size = new System.Drawing.Size(67, 23);
            this.txt_j5.TabIndex = 2;
            this.txt_j5.Text = "0";
            this.txt_j5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_j4
            // 
            this.txt_j4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_j4.Location = new System.Drawing.Point(394, 141);
            this.txt_j4.Margin = new System.Windows.Forms.Padding(2);
            this.txt_j4.Name = "txt_j4";
            this.txt_j4.Size = new System.Drawing.Size(67, 23);
            this.txt_j4.TabIndex = 2;
            this.txt_j4.Text = "0";
            this.txt_j4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_j3
            // 
            this.txt_j3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_j3.Location = new System.Drawing.Point(394, 103);
            this.txt_j3.Margin = new System.Windows.Forms.Padding(2);
            this.txt_j3.Name = "txt_j3";
            this.txt_j3.Size = new System.Drawing.Size(67, 23);
            this.txt_j3.TabIndex = 2;
            this.txt_j3.Text = "0";
            this.txt_j3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_j2
            // 
            this.txt_j2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_j2.Location = new System.Drawing.Point(394, 65);
            this.txt_j2.Margin = new System.Windows.Forms.Padding(2);
            this.txt_j2.Name = "txt_j2";
            this.txt_j2.Size = new System.Drawing.Size(67, 23);
            this.txt_j2.TabIndex = 2;
            this.txt_j2.Text = "0";
            this.txt_j2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_j1
            // 
            this.txt_j1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_j1.Location = new System.Drawing.Point(394, 28);
            this.txt_j1.Margin = new System.Windows.Forms.Padding(2);
            this.txt_j1.Name = "txt_j1";
            this.txt_j1.Size = new System.Drawing.Size(67, 23);
            this.txt_j1.TabIndex = 2;
            this.txt_j1.Text = "0";
            this.txt_j1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(13, 221);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(26, 20);
            this.label19.TabIndex = 1;
            this.label19.Text = "J6";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(13, 182);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(26, 20);
            this.label18.TabIndex = 1;
            this.label18.Text = "J5";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(10, 141);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(26, 20);
            this.label17.TabIndex = 1;
            this.label17.Text = "J4";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(10, 102);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(26, 20);
            this.label16.TabIndex = 1;
            this.label16.Text = "J3";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(10, 65);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(26, 20);
            this.label15.TabIndex = 1;
            this.label15.Text = "J2";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(12, 28);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(26, 20);
            this.label14.TabIndex = 1;
            this.label14.Text = "J1";
            // 
            // hscroll_J6
            // 
            this.hscroll_J6.Location = new System.Drawing.Point(38, 220);
            this.hscroll_J6.Name = "hscroll_J6";
            this.hscroll_J6.Size = new System.Drawing.Size(353, 27);
            this.hscroll_J6.TabIndex = 0;
            this.hscroll_J6.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hscroll_J6_Scroll);
            // 
            // hscroll_J5
            // 
            this.hscroll_J5.Location = new System.Drawing.Point(38, 182);
            this.hscroll_J5.Name = "hscroll_J5";
            this.hscroll_J5.Size = new System.Drawing.Size(353, 27);
            this.hscroll_J5.TabIndex = 0;
            this.hscroll_J5.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hscroll_J5_Scroll);
            // 
            // hscroll_J4
            // 
            this.hscroll_J4.Location = new System.Drawing.Point(38, 141);
            this.hscroll_J4.Name = "hscroll_J4";
            this.hscroll_J4.Size = new System.Drawing.Size(353, 27);
            this.hscroll_J4.TabIndex = 0;
            this.hscroll_J4.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hscroll_J4_Scroll);
            // 
            // hscroll_J3
            // 
            this.hscroll_J3.Location = new System.Drawing.Point(38, 103);
            this.hscroll_J3.Name = "hscroll_J3";
            this.hscroll_J3.Size = new System.Drawing.Size(353, 27);
            this.hscroll_J3.TabIndex = 0;
            this.hscroll_J3.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hscroll_J3_Scroll);
            // 
            // hscroll_J2
            // 
            this.hscroll_J2.Location = new System.Drawing.Point(38, 65);
            this.hscroll_J2.Name = "hscroll_J2";
            this.hscroll_J2.Size = new System.Drawing.Size(353, 27);
            this.hscroll_J2.TabIndex = 0;
            this.hscroll_J2.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hscroll_J2_Scroll);
            // 
            // hscroll_J1
            // 
            this.hscroll_J1.Location = new System.Drawing.Point(38, 28);
            this.hscroll_J1.Name = "hscroll_J1";
            this.hscroll_J1.Size = new System.Drawing.Size(353, 27);
            this.hscroll_J1.TabIndex = 0;
            this.hscroll_J1.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hscroll_J1_Scroll);
            // 
            // hScroll_RX
            // 
            this.hScroll_RX.Location = new System.Drawing.Point(44, 141);
            this.hScroll_RX.Name = "hScroll_RX";
            this.hScroll_RX.Size = new System.Drawing.Size(214, 23);
            this.hScroll_RX.TabIndex = 5;
            this.hScroll_RX.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScroll_RX_Scroll);
            // 
            // hScroll_TZ
            // 
            this.hScroll_TZ.Location = new System.Drawing.Point(44, 101);
            this.hScroll_TZ.Name = "hScroll_TZ";
            this.hScroll_TZ.Size = new System.Drawing.Size(214, 21);
            this.hScroll_TZ.TabIndex = 3;
            this.hScroll_TZ.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScroll_TZ_Scroll);
            // 
            // hScroll_RY
            // 
            this.hScroll_RY.Location = new System.Drawing.Point(44, 179);
            this.hScroll_RY.Name = "hScroll_RY";
            this.hScroll_RY.Size = new System.Drawing.Size(214, 23);
            this.hScroll_RY.TabIndex = 4;
            this.hScroll_RY.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScroll_RY_Scroll);
            // 
            // hScroll_RZ
            // 
            this.hScroll_RZ.Location = new System.Drawing.Point(44, 217);
            this.hScroll_RZ.Name = "hScroll_RZ";
            this.hScroll_RZ.Size = new System.Drawing.Size(214, 23);
            this.hScroll_RZ.TabIndex = 3;
            this.hScroll_RZ.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScroll_RZ_Scroll);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(9, 27);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "TX";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(9, 141);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 20);
            this.label4.TabIndex = 8;
            this.label4.Text = "RX";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(11, 66);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 20);
            this.label2.TabIndex = 7;
            this.label2.Text = "TY";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(7, 179);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(32, 20);
            this.label5.TabIndex = 7;
            this.label5.Text = "RY";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(10, 103);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(28, 20);
            this.label1.TabIndex = 6;
            this.label1.Text = "TZ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(7, 215);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(31, 20);
            this.label6.TabIndex = 6;
            this.label6.Text = "RZ";
            // 
            // txt_tx
            // 
            this.txt_tx.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_tx.Location = new System.Drawing.Point(261, 24);
            this.txt_tx.Margin = new System.Windows.Forms.Padding(2);
            this.txt_tx.Name = "txt_tx";
            this.txt_tx.Size = new System.Drawing.Size(183, 23);
            this.txt_tx.TabIndex = 11;
            this.txt_tx.Text = "0";
            this.txt_tx.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_rx
            // 
            this.txt_rx.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_rx.Location = new System.Drawing.Point(261, 140);
            this.txt_rx.Margin = new System.Windows.Forms.Padding(2);
            this.txt_rx.Name = "txt_rx";
            this.txt_rx.Size = new System.Drawing.Size(183, 23);
            this.txt_rx.TabIndex = 11;
            this.txt_rx.Text = "0";
            this.txt_rx.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_ty
            // 
            this.txt_ty.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ty.Location = new System.Drawing.Point(261, 62);
            this.txt_ty.Margin = new System.Windows.Forms.Padding(2);
            this.txt_ty.Name = "txt_ty";
            this.txt_ty.Size = new System.Drawing.Size(183, 23);
            this.txt_ty.TabIndex = 10;
            this.txt_ty.Text = "0";
            this.txt_ty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_ry
            // 
            this.txt_ry.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ry.Location = new System.Drawing.Point(261, 178);
            this.txt_ry.Margin = new System.Windows.Forms.Padding(2);
            this.txt_ry.Name = "txt_ry";
            this.txt_ry.Size = new System.Drawing.Size(183, 23);
            this.txt_ry.TabIndex = 10;
            this.txt_ry.Text = "0";
            this.txt_ry.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_tz
            // 
            this.txt_tz.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_tz.Location = new System.Drawing.Point(261, 100);
            this.txt_tz.Margin = new System.Windows.Forms.Padding(2);
            this.txt_tz.Name = "txt_tz";
            this.txt_tz.Size = new System.Drawing.Size(183, 23);
            this.txt_tz.TabIndex = 9;
            this.txt_tz.Text = "0";
            this.txt_tz.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_rz
            // 
            this.txt_rz.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_rz.Location = new System.Drawing.Point(261, 216);
            this.txt_rz.Margin = new System.Windows.Forms.Padding(2);
            this.txt_rz.Name = "txt_rz";
            this.txt_rz.Size = new System.Drawing.Size(183, 23);
            this.txt_rz.TabIndex = 9;
            this.txt_rz.Text = "0";
            this.txt_rz.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txt_rz);
            this.groupBox1.Controls.Add(this.txt_tz);
            this.groupBox1.Controls.Add(this.txt_ry);
            this.groupBox1.Controls.Add(this.txt_ty);
            this.groupBox1.Controls.Add(this.txt_rx);
            this.groupBox1.Controls.Add(this.txt_tx);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.hScroll_RZ);
            this.groupBox1.Controls.Add(this.hScroll_RY);
            this.groupBox1.Controls.Add(this.hScroll_TZ);
            this.groupBox1.Controls.Add(this.hScroll_RX);
            this.groupBox1.Controls.Add(this.hScroll_TY);
            this.groupBox1.Controls.Add(this.hScroll_TX);
            this.groupBox1.ForeColor = System.Drawing.Color.Yellow;
            this.groupBox1.Location = new System.Drawing.Point(487, 210);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(454, 258);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "IK Control";
            // 
            // hScroll_TY
            // 
            this.hScroll_TY.Location = new System.Drawing.Point(44, 63);
            this.hScroll_TY.Name = "hScroll_TY";
            this.hScroll_TY.Size = new System.Drawing.Size(214, 22);
            this.hScroll_TY.TabIndex = 4;
            this.hScroll_TY.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScroll_TY_Scroll);
            // 
            // hScroll_TX
            // 
            this.hScroll_TX.Location = new System.Drawing.Point(44, 25);
            this.hScroll_TX.Name = "hScroll_TX";
            this.hScroll_TX.Size = new System.Drawing.Size(214, 22);
            this.hScroll_TX.TabIndex = 5;
            this.hScroll_TX.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScroll_TX_Scroll);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.txt_build);
            this.groupBox2.Controls.Add(this.txt_API_Version);
            this.groupBox2.Controls.Add(this.txt_API);
            this.groupBox2.Controls.Add(this.txt_type);
            this.groupBox2.Controls.Add(this.txt_item_id);
            this.groupBox2.Controls.Add(this.txt_robot_name);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.groupBox2.Location = new System.Drawing.Point(12, 48);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(243, 156);
            this.groupBox2.TabIndex = 16;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Robot Info";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(60, 130);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(35, 15);
            this.label12.TabIndex = 1;
            this.label12.Text = "Build";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(26, 108);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(69, 15);
            this.label11.TabIndex = 1;
            this.label11.Text = "API Version";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(70, 87);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(25, 15);
            this.label10.TabIndex = 1;
            this.label10.Text = "API";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(62, 63);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(33, 15);
            this.label9.TabIndex = 1;
            this.label9.Text = "Type";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(49, 40);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(46, 15);
            this.label8.TabIndex = 1;
            this.label8.Text = "Item ID";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(18, 16);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 15);
            this.label7.TabIndex = 1;
            this.label7.Text = "Robot Name";
            // 
            // txt_build
            // 
            this.txt_build.Location = new System.Drawing.Point(97, 128);
            this.txt_build.Name = "txt_build";
            this.txt_build.Size = new System.Drawing.Size(136, 22);
            this.txt_build.TabIndex = 0;
            // 
            // txt_API_Version
            // 
            this.txt_API_Version.Location = new System.Drawing.Point(97, 106);
            this.txt_API_Version.Name = "txt_API_Version";
            this.txt_API_Version.Size = new System.Drawing.Size(136, 22);
            this.txt_API_Version.TabIndex = 0;
            // 
            // txt_API
            // 
            this.txt_API.Location = new System.Drawing.Point(97, 82);
            this.txt_API.Name = "txt_API";
            this.txt_API.Size = new System.Drawing.Size(136, 22);
            this.txt_API.TabIndex = 0;
            // 
            // txt_type
            // 
            this.txt_type.Location = new System.Drawing.Point(97, 59);
            this.txt_type.Name = "txt_type";
            this.txt_type.Size = new System.Drawing.Size(136, 22);
            this.txt_type.TabIndex = 0;
            // 
            // txt_item_id
            // 
            this.txt_item_id.Location = new System.Drawing.Point(97, 36);
            this.txt_item_id.Name = "txt_item_id";
            this.txt_item_id.Size = new System.Drawing.Size(136, 22);
            this.txt_item_id.TabIndex = 0;
            // 
            // txt_robot_name
            // 
            this.txt_robot_name.Location = new System.Drawing.Point(97, 13);
            this.txt_robot_name.Name = "txt_robot_name";
            this.txt_robot_name.Size = new System.Drawing.Size(136, 22);
            this.txt_robot_name.TabIndex = 0;
            // 
            // btn_get_Position
            // 
            this.btn_get_Position.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_get_Position.Location = new System.Drawing.Point(17, 19);
            this.btn_get_Position.Name = "btn_get_Position";
            this.btn_get_Position.Size = new System.Drawing.Size(130, 26);
            this.btn_get_Position.TabIndex = 17;
            this.btn_get_Position.Text = "GET JOINTS";
            this.btn_get_Position.UseVisualStyleBackColor = true;
            this.btn_get_Position.Click += new System.EventHandler(this.btn_get_Position_Click);
            // 
            // txt_Get_Joints
            // 
            this.txt_Get_Joints.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Get_Joints.Location = new System.Drawing.Point(160, 19);
            this.txt_Get_Joints.Name = "txt_Get_Joints";
            this.txt_Get_Joints.Size = new System.Drawing.Size(510, 26);
            this.txt_Get_Joints.TabIndex = 18;
            // 
            // txt_set_joints
            // 
            this.txt_set_joints.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_set_joints.Location = new System.Drawing.Point(160, 51);
            this.txt_set_joints.Name = "txt_set_joints";
            this.txt_set_joints.Size = new System.Drawing.Size(510, 26);
            this.txt_set_joints.TabIndex = 18;
            this.txt_set_joints.Text = "0.0 , 0.0 , 0.0 , 0 , 0.0 , 0.0";
            // 
            // btn_set_joints
            // 
            this.btn_set_joints.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_set_joints.Location = new System.Drawing.Point(17, 51);
            this.btn_set_joints.Name = "btn_set_joints";
            this.btn_set_joints.Size = new System.Drawing.Size(130, 26);
            this.btn_set_joints.TabIndex = 19;
            this.btn_set_joints.Text = "SET JOINTS";
            this.btn_set_joints.UseVisualStyleBackColor = true;
            this.btn_set_joints.Click += new System.EventHandler(this.btn_set_joints_Click);
            // 
            // txt_get_pos
            // 
            this.txt_get_pos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_get_pos.Location = new System.Drawing.Point(160, 83);
            this.txt_get_pos.Name = "txt_get_pos";
            this.txt_get_pos.Size = new System.Drawing.Size(510, 26);
            this.txt_get_pos.TabIndex = 18;
            // 
            // txt_set_pos
            // 
            this.txt_set_pos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_set_pos.Location = new System.Drawing.Point(160, 115);
            this.txt_set_pos.Name = "txt_set_pos";
            this.txt_set_pos.Size = new System.Drawing.Size(510, 26);
            this.txt_set_pos.TabIndex = 18;
            this.txt_set_pos.Text = "0.0 , 0.0 , 0.0 , 0 , 0.0 , 0.0";
            // 
            // btn_get_pos
            // 
            this.btn_get_pos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_get_pos.Location = new System.Drawing.Point(17, 84);
            this.btn_get_pos.Name = "btn_get_pos";
            this.btn_get_pos.Size = new System.Drawing.Size(130, 25);
            this.btn_get_pos.TabIndex = 20;
            this.btn_get_pos.Text = "GET POSITION";
            this.btn_get_pos.UseVisualStyleBackColor = true;
            this.btn_get_pos.Click += new System.EventHandler(this.btn_get_pos_Click);
            // 
            // btn_set_pos
            // 
            this.btn_set_pos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_set_pos.Location = new System.Drawing.Point(16, 116);
            this.btn_set_pos.Name = "btn_set_pos";
            this.btn_set_pos.Size = new System.Drawing.Size(130, 25);
            this.btn_set_pos.TabIndex = 20;
            this.btn_set_pos.Text = "SET POSITION";
            this.btn_set_pos.UseVisualStyleBackColor = true;
            this.btn_set_pos.Click += new System.EventHandler(this.btn_set_pos_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btn_get_Position);
            this.groupBox5.Controls.Add(this.btn_set_pos);
            this.groupBox5.Controls.Add(this.txt_Get_Joints);
            this.groupBox5.Controls.Add(this.btn_get_pos);
            this.groupBox5.Controls.Add(this.txt_set_joints);
            this.groupBox5.Controls.Add(this.btn_set_joints);
            this.groupBox5.Controls.Add(this.txt_get_pos);
            this.groupBox5.Controls.Add(this.txt_set_pos);
            this.groupBox5.ForeColor = System.Drawing.Color.Yellow;
            this.groupBox5.Location = new System.Drawing.Point(261, 49);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(680, 156);
            this.groupBox5.TabIndex = 21;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Joints and Position Control";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btn_draw);
            this.groupBox3.Controls.Add(this.dg_param);
            this.groupBox3.ForeColor = System.Drawing.Color.Yellow;
            this.groupBox3.Location = new System.Drawing.Point(947, 48);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(364, 451);
            this.groupBox3.TabIndex = 23;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Parameter Range";
            // 
            // dg_param
            // 
            this.dg_param.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_param.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3});
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dg_param.DefaultCellStyle = dataGridViewCellStyle1;
            this.dg_param.Location = new System.Drawing.Point(13, 24);
            this.dg_param.Name = "dg_param";
            this.dg_param.Size = new System.Drawing.Size(333, 380);
            this.dg_param.TabIndex = 0;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "PARAMETER";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "MAX VALUE";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.HeaderText = "MIN VALUE";
            this.Column3.Name = "Column3";
            // 
            // btn_draw
            // 
            this.btn_draw.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_draw.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btn_draw.Location = new System.Drawing.Point(22, 411);
            this.btn_draw.Name = "btn_draw";
            this.btn_draw.Size = new System.Drawing.Size(324, 34);
            this.btn_draw.TabIndex = 1;
            this.btn_draw.Text = "DRAW";
            this.btn_draw.UseVisualStyleBackColor = true;
            this.btn_draw.Click += new System.EventHandler(this.btn_draw_Click);
            // 
            // frm_main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.ClientSize = new System.Drawing.Size(1325, 507);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.txt_msg);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.Name = "frm_main";
            this.Text = "Forward and Inverse Kinematics Demonstration using RoboDK and C#";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dg_param)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txt_msg;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txt_j6;
        private System.Windows.Forms.TextBox txt_j5;
        private System.Windows.Forms.TextBox txt_j4;
        private System.Windows.Forms.TextBox txt_j3;
        private System.Windows.Forms.TextBox txt_j2;
        private System.Windows.Forms.TextBox txt_j1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.HScrollBar hscroll_J6;
        private System.Windows.Forms.HScrollBar hscroll_J5;
        private System.Windows.Forms.HScrollBar hscroll_J4;
        private System.Windows.Forms.HScrollBar hscroll_J3;
        private System.Windows.Forms.HScrollBar hscroll_J2;
        private System.Windows.Forms.HScrollBar hscroll_J1;
        private System.Windows.Forms.HScrollBar hScroll_RX;
        private System.Windows.Forms.HScrollBar hScroll_TZ;
        private System.Windows.Forms.HScrollBar hScroll_RY;
        private System.Windows.Forms.HScrollBar hScroll_RZ;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_tx;
        private System.Windows.Forms.TextBox txt_rx;
        private System.Windows.Forms.TextBox txt_ty;
        private System.Windows.Forms.TextBox txt_ry;
        private System.Windows.Forms.TextBox txt_tz;
        private System.Windows.Forms.TextBox txt_rz;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.HScrollBar hScroll_TY;
        private System.Windows.Forms.HScrollBar hScroll_TX;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txt_build;
        private System.Windows.Forms.TextBox txt_API_Version;
        private System.Windows.Forms.TextBox txt_API;
        private System.Windows.Forms.TextBox txt_type;
        private System.Windows.Forms.TextBox txt_item_id;
        private System.Windows.Forms.TextBox txt_robot_name;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btn_get_Position;
        private System.Windows.Forms.TextBox txt_Get_Joints;
        private System.Windows.Forms.TextBox txt_set_joints;
        private System.Windows.Forms.Button btn_set_joints;
        private System.Windows.Forms.TextBox txt_get_pos;
        private System.Windows.Forms.TextBox txt_set_pos;
        private System.Windows.Forms.Button btn_get_pos;
        private System.Windows.Forms.Button btn_set_pos;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView dg_param;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.Button btn_draw;
    }
}

