﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
//_________________________________________________________________________________________________________________
namespace Tools
{
    //_________________________________________________________________________________________________________________
    class IP_Client
    {
        private Socket socket;
        public int port = 20500;
        public string ip_addr = "127.0.0.1";
        public bool connected = false;
        public bool disposed=false;

        public byte[] bfr_tx = new byte[1500];
        int bfr_ptr = 0;
        //_________________________________________________________________________________________________________________
        public IP_Client()
        {
            socket = null;
        }
        //______________________________________________________________________________________________________________________
        public void connect()
        {
            socket = null;
            try
            {
                socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.IP)
                {
                    SendTimeout = 1000,
                    ReceiveTimeout = 1000
                };
                socket.Connect(ip_addr, port);
                socket.Poll(10000, SelectMode.SelectRead);
                connected=true;
            }
            catch (SocketException)
            {
                socket.Dispose();
                connected=false;
                disposed = true;
            }
        }
        //________________________________________________________________________________________________________________
        public void connect(String ip_addr, int port)
        {
            this.ip_addr = ip_addr;
            this.port = port;
            connect();
        }
        //________________________________________________________________________________________________________________
        public void Dispose()
        {
            if (disposed)
            {
                if (socket != null)
                {
                    try
                    {
                        socket.Shutdown(SocketShutdown.Both);
                    }
                    finally
                    {
                        socket.Close();
                        socket.Dispose();
                    }
                }
                disposed = true;
            }
        }
        //______________________________________________________________________________________________________________________
        public bool Poll(int microSeconds, SelectMode mode)
        {
            return socket.Poll(microSeconds,mode);
        }
        //______________________________________________________________________________________________________________________
        public bool Poll()
        {
            return socket.Poll(10000, SelectMode.SelectRead); 
        }
        //________________________________________________________________________________________________________________
        public void clear_buffer()
        {
            Array.Clear(bfr_tx, 0, bfr_tx.Length);
            bfr_ptr = 0;
        }
        //____________________________________________________________________________________________________________________
        public void push_Array(double[] arr)
        {
            int count = arr.Count(); // push no. of joints
            for (var i = 0; i < count; i++)
            {
                push_with_reverse(arr[i]);
            }
        }
        //____________________________________________________________________________________________________________________
        public void push(string val)
        {
            byte[] src = Encoding.ASCII.GetBytes(val);
            Array.Copy(src, 0, bfr_tx, bfr_ptr, src.Length);
            bfr_ptr += src.Length;
        }
        //__________________________________________________________________________________________________________________
        public void push_with_reverse(int val)  
        {
            byte[] intBytes = BitConverter.GetBytes(val);
            Array.Reverse(intBytes);
            push(intBytes);
        }
        //____________________________________________________________________________________________________________________
        public void push(byte[] src)
        {
            Array.Copy(src, 0, bfr_tx, bfr_ptr, src.Length);
            bfr_ptr += src.Length;
        }
        //____________________________________________________________________________________________________________________
       public void push_with_reverse(UInt64 val)
        {
            byte[] intBytes = BitConverter.GetBytes(val);
            Array.Reverse(intBytes);
            push(intBytes); 
        }
        //____________________________________________________________________________________________________________________
        public void push_with_reverse(double val)
        {
            byte[] intBytes = BitConverter.GetBytes((long)val);
            Array.Reverse(intBytes);
            push(intBytes);
        }
        //____________________________________________________________________________________________________________________
        public void push(double val)
        {
            byte[] intBytes = BitConverter.GetBytes(val);
            push(intBytes);
        }
        //____________________________________________________________________________________________________________________
        public void send()
        {
            if (!disposed)
            {
                var n = socket.Send(bfr_tx, bfr_ptr, SocketFlags.None);
            }
        }
        //__________________________________________________________________________________________________________________
        private void send(byte[] data, int count)
        {
            if (!disposed)
            {
                var n = socket.Send(data, count, SocketFlags.None);
            }
        }
        //___________________________________________________________________________________________________________________
        private void send(byte[] data)
        {
            if (!disposed)
            {
                var n = socket.Send(data, data.Count(), SocketFlags.None);
            }
        }
        //____________________________________________________________________________________________________________________
        public void ReceiveData(byte[] data, int len)
        {
            ReceiveData(data, 0, len);
        }
        //__________________________________________________________________________________________________________________
        public void ReceiveData(byte[] data, int offset, int len)
        {
            var receivedBytes = 0;
            while (receivedBytes < len)
            {
                var n = socket.Receive(data, offset + receivedBytes, len - receivedBytes, SocketFlags.None);
                receivedBytes += n;
            }
        }
        //_________________________________________________________________________________________________________________
        public string read_line()
        {
            var byteBuffer = new byte[1];
            var stringBuffer = new List<byte>(1000);
            ReceiveData(byteBuffer, 1);
            while (byteBuffer[0] != '\n')
            {
                stringBuffer.Add(byteBuffer[0]);
                ReceiveData(byteBuffer, 1);
            }
            string s = Encoding.UTF8.GetString(stringBuffer.ToArray());
            return s;
        }
        //_________________________________________________________________________________________________________________
        public UInt32 read_int()
        {
            if (!disposed)
            {
                byte[] b1 = new byte[4];
                var receivedBytes = 0;
                int len = 4;
                while (receivedBytes < len)
                {
                    var n = socket.Receive(b1, 0 + receivedBytes, len - receivedBytes, SocketFlags.None);
                    receivedBytes += n;
                }
                Array.Reverse(b1);
                UInt32 i = BitConverter.ToUInt32(b1, 0);
                return i;
            }
            else
            {
                return 0;
            }
        }
        //_________________________________________________________________________________________________________________
        public byte[] read_Bytes(UInt16 byte_count)
        {
            byte[] b1 = new byte[byte_count];
            var receivedBytes = 0;
            int len = byte_count;
            while (receivedBytes < len)
            {
                var n = socket.Receive(b1, 0 + receivedBytes, len - receivedBytes, SocketFlags.None);
                receivedBytes += n;
            }
            return b1;
        }
        //_________________________________________________________________________________________________________________
        public UInt64 read_double()
        {
            byte[] b1 = new byte[8];
            var receivedBytes = 0;
            int len = 8;
            while (receivedBytes < len)
            {
                var n = socket.Receive(b1, 0 + receivedBytes, len - receivedBytes, SocketFlags.None);
                receivedBytes += n;
            }
            Array.Reverse(b1);
            UInt64 i = BitConverter.ToUInt64(b1, 0);
            return i;
        }
        //_________________________________________________________________________________________________________________
        public byte[] Get_Bytes_From_Double_Array(double[] bfr)
        {
            int bfr_ptr = 0;
            byte[] b = new byte[bfr.Length * 8];
            for (var i = 0; i < bfr.Length; i++)
            {
                byte[] intBytes = BitConverter.GetBytes(bfr[i]);
                Array.Reverse(intBytes);
                Array.Copy(intBytes, 0, b, bfr_ptr, intBytes.Length);
                bfr_ptr += intBytes.Length;
            }
            return b;
        }
        //__________________________________________________________________________________________________________________________





    }// class
}// namespace
